package benchmarks

import (
	"context"
	"crypto/sha256"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strconv"
	"testing"
	"time"

	"filemanager/engine/api"
	"filemanager/engine/internal/catalog"
	"filemanager/engine/internal/exact"
	"filemanager/engine/internal/generation"
	"filemanager/engine/internal/workload"
)

const (
	m2MeasurementEnvironment         = "FILEMAN_ENGINE_M2_MEASURE"
	deltaCandidateHeaderRewriteBytes = 256
)

// TestImmutableGenerationDistribution is a component measurement, not a
// service-promotion result. It intentionally drops the reference shard before
// measuring reopened-reader heap so a complete heap mirror cannot hide in the
// number.
func TestImmutableGenerationDistribution(t *testing.T) {
	if os.Getenv(m2MeasurementEnvironment) != "1" {
		t.Skipf("set %s=1 to run durable-generation measurements", m2MeasurementEnvironment)
	}
	recordCount := 1_000_000
	if encoded := os.Getenv("FILEMAN_ENGINE_RECORDS"); encoded != "" {
		parsed, err := strconv.Atoi(encoded)
		if err != nil || parsed < 10_000 {
			t.Fatalf("FILEMAN_ENGINE_RECORDS=%q is not an integer at least 10000", encoded)
		}
		recordCount = parsed
	}
	directory := t.TempDir()
	root := api.RootSpec{ID: "fixture", Path: filepath.Join(t.TempDir(), "indexed")}

	runtime.GC()
	var baseline runtime.MemStats
	runtime.ReadMemStats(&baseline)
	corpus, err := workload.ScaleV1(recordCount, 10, 10)
	if err != nil {
		t.Fatal(err)
	}
	buildStarted := time.Now()
	shard, err := corpus.ReferenceShard(root)
	if err != nil {
		t.Fatal(err)
	}
	buildElapsed := time.Since(buildStarted)
	referenceDigest := shard.Digest()
	uniqueIndex := recordCount/2 + 1
	uniqueName := fmt.Sprintf("file-%09d", uniqueIndex)
	uniquePath := filepath.Join(root.Path, fmt.Sprintf("dir-%07d", uniqueIndex/10), uniqueName)
	wantPath, exists := shard.Path(uniquePath)
	if !exists {
		t.Fatalf("reference unique path %q is missing", uniquePath)
	}
	wantRepeated := referenceRecords(shard, shard.NameRange("repeated"), 100)

	store, err := generation.OpenStore(directory, nil)
	if err != nil {
		t.Fatal(err)
	}
	runtime.GC()
	var publishMemoryBefore runtime.MemStats
	runtime.ReadMemStats(&publishMemoryBefore)
	publishStarted := time.Now()
	reader, err := store.Publish(1, shard)
	if err != nil {
		t.Fatal(err)
	}
	publishElapsed := time.Since(publishStarted)
	var publishMemoryAfter runtime.MemStats
	runtime.ReadMemStats(&publishMemoryAfter)
	publishAllocated := publishMemoryAfter.TotalAlloc - publishMemoryBefore.TotalAlloc
	publishTransientHeapGrowth := positiveDifference(publishMemoryAfter.HeapAlloc, publishMemoryBefore.HeapAlloc)
	publishMallocs := publishMemoryAfter.Mallocs - publishMemoryBefore.Mallocs
	runtime.GC()
	var publishMemoryReclaimed runtime.MemStats
	runtime.ReadMemStats(&publishMemoryReclaimed)
	publishRetainedHeapGrowth := positiveDifference(publishMemoryReclaimed.HeapAlloc, publishMemoryBefore.HeapAlloc)
	metadata := reader.Metadata()
	if metadata.CatalogDigest != referenceDigest {
		t.Fatal("durable catalogue digest differs from the reference")
	}
	if err := reader.Close(); err != nil {
		t.Fatal(err)
	}
	initialStoreBytes, err := regularFileBytes(directory)
	if err != nil {
		t.Fatal(err)
	}
	initialManifest, err := os.Stat(filepath.Join(directory, "MANIFEST.1"))
	if err != nil {
		t.Fatal(err)
	}
	const segmentHeaderRewriteBytes = 512
	initialWriteLowerBound := metadata.Size + segmentHeaderRewriteBytes + uint64(initialManifest.Size())

	corpus = workload.Corpus{}
	shard = nil
	runtime.GC()
	var reopenedBaseline runtime.MemStats
	runtime.ReadMemStats(&reopenedBaseline)
	probeStarted := time.Now()
	head, err := store.Probe()
	if err != nil {
		t.Fatal(err)
	}
	probeElapsed := time.Since(probeStarted)
	if !head.IntegrityPending || head.Metadata.CatalogDigest != referenceDigest {
		t.Fatal("manifest probe lost its pending-integrity or reference-digest evidence")
	}
	recoverStarted := time.Now()
	reopened, err := store.Recover()
	if err != nil {
		t.Fatal(err)
	}
	recoverElapsed := time.Since(recoverStarted)
	runtime.GC()
	var reopenedMemory runtime.MemStats
	runtime.ReadMemStats(&reopenedMemory)
	reopenedHeap := uint64(0)
	if reopenedMemory.HeapAlloc > reopenedBaseline.HeapAlloc {
		reopenedHeap = reopenedMemory.HeapAlloc - reopenedBaseline.HeapAlloc
	}

	gotPath, exists, err := reopened.Path(uniquePath)
	if err != nil || !exists || gotPath != wantPath {
		t.Fatalf("durable path mismatch: exists=%v err=%v\n got  %+v\n want %+v", exists, err, gotPath, wantPath)
	}
	gotRepeated, err := reopened.Name("repeated", 100)
	if err != nil {
		t.Fatal(err)
	}
	if !sameRecords(gotRepeated, wantRepeated) {
		t.Fatal("durable repeated-name results differ from reference order")
	}

	uniqueSamples, uniqueResultDigest := sampleGenerationPath(t, reopened, uniquePath, 20_000)
	repeatedSamples, repeatedResultDigest := sampleGenerationName(t, reopened, "repeated", 100, 2_000)
	policy := catalog.NewStore()
	if _, _, err := policy.ApplyRoots([]api.RootSpec{root}); err != nil {
		t.Fatal(err)
	}
	pipelineSamples, pipelineDigest := sampleGenerationPipeline(t, policy.Snapshot(), reopened, api.Query{
		Scope: api.Scope{Root: root.ID, Descendants: true}, Filters: map[string]string{"name": "repeated"}, Limit: 100,
	}, 2_000)
	runtime.GC()
	var warmedMemory runtime.MemStats
	runtime.ReadMemStats(&warmedMemory)
	warmedHeap := uint64(0)
	if warmedMemory.HeapAlloc > reopenedBaseline.HeapAlloc {
		warmedHeap = warmedMemory.HeapAlloc - reopenedBaseline.HeapAlloc
	}
	t.Logf("environment os=%s arch=%s go=%s", runtime.GOOS, runtime.GOARCH, runtime.Version())
	t.Logf("generation-build file_objects=%d bindings=%d reference_build=%s publish=%s manifest_probe=%s recover_checked=%s", recordCount, metadata.BindingCount, buildElapsed, publishElapsed, probeElapsed, recoverElapsed)
	t.Logf("generation-storage bytes=%d bytes_per_binding=%.2f reopened_heap_delta=%d warmed_heap_delta=%d cache_bytes=%d cache_limit=%d", metadata.Size, float64(metadata.Size)/float64(metadata.BindingCount), reopenedHeap, warmedHeap, reopened.CacheBytes(), generation.ReadCacheLimit)
	t.Logf("generation-publication allocated_bytes=%d transient_heap_growth=%d retained_heap_growth=%d mallocs=%d live_store_bytes=%d write_lower_bound=%d", publishAllocated, publishTransientHeapGrowth, publishRetainedHeapGrowth, publishMallocs, initialStoreBytes, initialWriteLowerBound)
	logDistribution(t, "generation-exact-path", uniqueSamples, uniqueResultDigest)
	logDistribution(t, "generation-name-first-100", repeatedSamples, repeatedResultDigest)
	logDistribution(t, "generation-pipeline-name-first-100", pipelineSamples, pipelineDigest)

	updateCorpus, err := workload.ScaleV1(recordCount, 10, 10)
	if err != nil {
		t.Fatal(err)
	}
	changed := false
	for index := range updateCorpus.Entries {
		if updateCorpus.Entries[index].Kind == api.ObjectRegular {
			updateCorpus.Entries[index].ModifiedUnixNano++
			changed = true
			break
		}
	}
	if !changed {
		t.Fatal("scale workload has no regular object to update")
	}
	updateBuildStarted := time.Now()
	updatedShard, err := updateCorpus.ReferenceShard(root)
	if err != nil {
		t.Fatal(err)
	}
	updateBuildElapsed := time.Since(updateBuildStarted)
	runtime.GC()
	var diffMemoryBefore runtime.MemStats
	runtime.ReadMemStats(&diffMemoryBefore)
	diffStarted := time.Now()
	diffSummary, err := generation.Diff(context.Background(), reopened, updatedShard, nil)
	if err != nil {
		t.Fatal(err)
	}
	diffElapsed := time.Since(diffStarted)
	var diffMemoryAfter runtime.MemStats
	runtime.ReadMemStats(&diffMemoryAfter)
	diffAllocated := diffMemoryAfter.TotalAlloc - diffMemoryBefore.TotalAlloc
	diffTransientHeapGrowth := positiveDifference(diffMemoryAfter.HeapAlloc, diffMemoryBefore.HeapAlloc)
	runtime.GC()
	var diffMemoryReclaimed runtime.MemStats
	runtime.ReadMemStats(&diffMemoryReclaimed)
	diffRetainedHeapGrowth := positiveDifference(diffMemoryReclaimed.HeapAlloc, diffMemoryBefore.HeapAlloc)
	if diffSummary.Changes() != 1 || diffSummary.Updated != 1 || diffSummary.Unchanged != uint64(updatedShard.Len()-1) {
		t.Fatalf("one-record diff summary=%+v", diffSummary)
	}
	t.Logf("generation-streaming-diff elapsed=%s added=%d updated=%d deleted=%d unchanged=%d allocated_bytes=%d transient_heap_growth=%d retained_heap_growth=%d",
		diffElapsed, diffSummary.Added, diffSummary.Updated, diffSummary.Deleted, diffSummary.Unchanged,
		diffAllocated, diffTransientHeapGrowth, diffRetainedHeapGrowth,
	)
	deltaPath := filepath.Join(t.TempDir(), "one-record.delta")
	runtime.GC()
	var deltaMemoryBefore runtime.MemStats
	runtime.ReadMemStats(&deltaMemoryBefore)
	deltaStarted := time.Now()
	deltaMetadata, err := generation.WriteDeltaCandidate(context.Background(), deltaPath, 2, reopened, updatedShard)
	if err != nil {
		t.Fatal(err)
	}
	deltaElapsed := time.Since(deltaStarted)
	var deltaMemoryAfter runtime.MemStats
	runtime.ReadMemStats(&deltaMemoryAfter)
	deltaAllocated := deltaMemoryAfter.TotalAlloc - deltaMemoryBefore.TotalAlloc
	deltaTransientHeapGrowth := positiveDifference(deltaMemoryAfter.HeapAlloc, deltaMemoryBefore.HeapAlloc)
	deltaReader, err := generation.OpenDeltaCandidate(deltaPath, root)
	if err != nil {
		t.Fatal(err)
	}
	if err := deltaReader.Check(); err != nil {
		t.Fatal(err)
	}
	var deltaRows uint64
	if err := deltaReader.Iterate(context.Background(), func(generation.ChangeKind, catalog.Row) error {
		deltaRows++
		return nil
	}); err != nil {
		t.Fatal(err)
	}
	if err := deltaReader.Close(); err != nil {
		t.Fatal(err)
	}
	runtime.GC()
	var deltaMemoryReclaimed runtime.MemStats
	runtime.ReadMemStats(&deltaMemoryReclaimed)
	deltaRetainedHeapGrowth := positiveDifference(deltaMemoryReclaimed.HeapAlloc, deltaMemoryBefore.HeapAlloc)
	if deltaRows != 1 || deltaMetadata.Updated != 1 || deltaMetadata.CatalogDigest != updatedShard.Digest() {
		t.Fatalf("one-record delta metadata=%+v rows=%d", deltaMetadata, deltaRows)
	}
	const canonicalChangedObjectBytes = 64
	deltaWriteLowerBound := deltaMetadata.Size + deltaCandidateHeaderRewriteBytes
	t.Logf("generation-delta-candidate-one-record-update canonical_changed_object_bytes=%d elapsed=%s file_bytes=%d write_lower_bound=%d write_amplification_per_changed_object=%.2f allocated_bytes=%d transient_heap_growth=%d retained_heap_growth=%d",
		canonicalChangedObjectBytes, deltaElapsed, deltaMetadata.Size, deltaWriteLowerBound,
		float64(deltaWriteLowerBound)/canonicalChangedObjectBytes, deltaAllocated, deltaTransientHeapGrowth, deltaRetainedHeapGrowth,
	)
	if err := reopened.Close(); err != nil {
		t.Fatal(err)
	}
	runtime.GC()
	var updateMemoryBefore runtime.MemStats
	runtime.ReadMemStats(&updateMemoryBefore)
	updatePublishStarted := time.Now()
	updatedReader, err := store.Publish(2, updatedShard)
	if err != nil {
		t.Fatal(err)
	}
	updatePublishElapsed := time.Since(updatePublishStarted)
	var updateMemoryAfter runtime.MemStats
	runtime.ReadMemStats(&updateMemoryAfter)
	updateAllocated := updateMemoryAfter.TotalAlloc - updateMemoryBefore.TotalAlloc
	updateTransientHeapGrowth := positiveDifference(updateMemoryAfter.HeapAlloc, updateMemoryBefore.HeapAlloc)
	updateMallocs := updateMemoryAfter.Mallocs - updateMemoryBefore.Mallocs
	runtime.GC()
	var updateMemoryReclaimed runtime.MemStats
	runtime.ReadMemStats(&updateMemoryReclaimed)
	updateRetainedHeapGrowth := positiveDifference(updateMemoryReclaimed.HeapAlloc, updateMemoryBefore.HeapAlloc)
	updatedMetadata := updatedReader.Metadata()
	if updatedMetadata.CatalogDigest == metadata.CatalogDigest {
		t.Fatal("one-record metadata update did not change the durable catalogue digest")
	}
	if err := updatedReader.Close(); err != nil {
		t.Fatal(err)
	}
	updatedStoreBytes, err := regularFileBytes(directory)
	if err != nil {
		t.Fatal(err)
	}
	updatedManifest, err := os.Stat(filepath.Join(directory, "MANIFEST.0"))
	if err != nil {
		t.Fatal(err)
	}
	updateWriteLowerBound := updatedMetadata.Size + segmentHeaderRewriteBytes + uint64(updatedManifest.Size())
	t.Logf("generation-full-snapshot-one-record-update changed_field_bytes=8 canonical_changed_object_bytes=%d rebuild=%s publish=%s allocated_bytes=%d transient_heap_growth=%d retained_heap_growth=%d mallocs=%d write_lower_bound=%d write_amplification_per_changed_object=%.2f live_store_before=%d live_store_after=%d",
		canonicalChangedObjectBytes, updateBuildElapsed, updatePublishElapsed,
		updateAllocated, updateTransientHeapGrowth, updateRetainedHeapGrowth, updateMallocs,
		updateWriteLowerBound, float64(updateWriteLowerBound)/canonicalChangedObjectBytes,
		initialStoreBytes, updatedStoreBytes,
	)
}

// TestDeltaCandidateBatchDistribution measures only the standalone run. It
// deliberately excludes manifest publication and amortized compaction, so a
// passing run-level amplification number is not an admission result.
func TestDeltaCandidateBatchDistribution(t *testing.T) {
	if os.Getenv(m2MeasurementEnvironment) != "1" {
		t.Skipf("set %s=1 to run delta-candidate measurements", m2MeasurementEnvironment)
	}
	recordCount := 1_000_000
	if encoded := os.Getenv("FILEMAN_ENGINE_RECORDS"); encoded != "" {
		parsed, err := strconv.Atoi(encoded)
		if err != nil || parsed < 10_000 {
			t.Fatalf("FILEMAN_ENGINE_RECORDS=%q is not an integer at least 10000", encoded)
		}
		recordCount = parsed
	}
	root := api.RootSpec{ID: "fixture", Path: filepath.Join(t.TempDir(), "indexed")}
	baseCorpus, err := workload.ScaleV1(recordCount, 10, 10)
	if err != nil {
		t.Fatal(err)
	}
	baseShard, err := baseCorpus.ReferenceShard(root)
	if err != nil {
		t.Fatal(err)
	}
	basePath := filepath.Join(t.TempDir(), "base.seg")
	if _, err := generation.Write(basePath, 1, baseShard); err != nil {
		t.Fatal(err)
	}
	baseCorpus = workload.Corpus{}
	baseShard = nil
	runtime.GC()
	base, err := generation.Open(basePath, root)
	if err != nil {
		t.Fatal(err)
	}
	defer base.Close()

	for _, batch := range []int{4_096, 10_000} {
		t.Run(fmt.Sprintf("updates-%d", batch), func(t *testing.T) {
			corpus, err := workload.ScaleV1(recordCount, 10, 10)
			if err != nil {
				t.Fatal(err)
			}
			changed := 0
			for index := range corpus.Entries {
				if corpus.Entries[index].Kind != api.ObjectRegular {
					continue
				}
				corpus.Entries[index].ModifiedUnixNano++
				changed++
				if changed == batch {
					break
				}
			}
			if changed != batch {
				t.Fatalf("changed %d regular files, want %d", changed, batch)
			}
			updated, err := corpus.ReferenceShard(root)
			if err != nil {
				t.Fatal(err)
			}
			corpus = workload.Corpus{}
			runtime.GC()
			var memoryBefore runtime.MemStats
			runtime.ReadMemStats(&memoryBefore)
			path := filepath.Join(t.TempDir(), "batch.delta")
			started := time.Now()
			metadata, err := generation.WriteDeltaCandidate(context.Background(), path, 2, base, updated)
			if err != nil {
				t.Fatal(err)
			}
			elapsed := time.Since(started)
			var memoryAfter runtime.MemStats
			runtime.ReadMemStats(&memoryAfter)
			allocated := memoryAfter.TotalAlloc - memoryBefore.TotalAlloc
			transient := positiveDifference(memoryAfter.HeapAlloc, memoryBefore.HeapAlloc)
			reader, err := generation.OpenDeltaCandidate(path, root)
			if err != nil {
				t.Fatal(err)
			}
			if err := reader.Check(); err != nil {
				t.Fatal(err)
			}
			var logicalBytes uint64
			var rows uint64
			if err := reader.Iterate(context.Background(), func(_ generation.ChangeKind, row catalog.Row) error {
				rows++
				logicalBytes += canonicalDeltaOperationBytes(row)
				return nil
			}); err != nil {
				t.Fatal(err)
			}
			if err := reader.Close(); err != nil {
				t.Fatal(err)
			}
			updated = nil
			runtime.GC()
			var memoryReclaimed runtime.MemStats
			runtime.ReadMemStats(&memoryReclaimed)
			retained := positiveDifference(memoryReclaimed.HeapAlloc, memoryBefore.HeapAlloc)
			writeLowerBound := metadata.Size + deltaCandidateHeaderRewriteBytes
			if rows != uint64(batch) || metadata.Updated != uint64(batch) || logicalBytes == 0 {
				t.Fatalf("batch metadata=%+v rows=%d logical_bytes=%d", metadata, rows, logicalBytes)
			}
			t.Logf("delta-candidate-batch records=%d elapsed=%s file_bytes=%d write_lower_bound=%d canonical_logical_bytes=%d run_write_amplification=%.4f allocated_bytes=%d transient_heap_growth=%d retained_heap_growth=%d",
				batch, elapsed, metadata.Size, writeLowerBound, logicalBytes,
				float64(writeLowerBound)/float64(logicalBytes), allocated, transient, retained,
			)
		})
	}
}

// Operation tag + v1 object record + parent identity + two string lengths +
// exact path/name bytes. This is the fixed denominator declared by the delta
// slice, not a denominator chosen from the candidate encoding.
func canonicalDeltaOperationBytes(row catalog.Row) uint64 {
	const operationTag = 1
	const objectRecord = 64
	const parentIdentity = 32
	const stringLengths = 8
	return operationTag + objectRecord + parentIdentity + stringLengths + uint64(len(row.RelativePath)+len(row.Name))
}

func positiveDifference(after, before uint64) uint64 {
	if after <= before {
		return 0
	}
	return after - before
}

func regularFileBytes(directory string) (uint64, error) {
	entries, err := os.ReadDir(directory)
	if err != nil {
		return 0, err
	}
	var total uint64
	for _, entry := range entries {
		if entry.IsDir() {
			continue
		}
		info, err := entry.Info()
		if err != nil {
			return 0, err
		}
		total += uint64(info.Size())
	}
	return total, nil
}

func sampleGenerationPipeline(t *testing.T, snapshot *catalog.Snapshot, reader *generation.Reader, query api.Query, count int) ([]time.Duration, string) {
	t.Helper()
	samples := make([]time.Duration, count)
	digest := sha256.New()
	var batchMemoryBefore runtime.MemStats = runtime.MemStats{}
	runtime.ReadMemStats(&batchMemoryBefore)
	var batchStarted time.Time = time.Now()
	for index := range samples {
		started := time.Now()
		matches, _, err := exact.QueryIndex(context.Background(), snapshot, reader.Metadata().Generation, reader.Root().ID, reader, query)
		samples[index] = time.Since(started)
		if err != nil || len(matches) != query.Limit {
			t.Fatalf("generation pipeline matches=%d err=%v", len(matches), err)
		}
		_, _ = digest.Write([]byte(matches[0].Record.ObjectID()))
	}
	var batchElapsed time.Duration = time.Since(batchStarted)
	var batchMemoryAfter runtime.MemStats = runtime.MemStats{}
	runtime.ReadMemStats(&batchMemoryAfter)
	var meanNanoseconds float64 = float64(batchElapsed.Nanoseconds()) / float64(count)
	var allocatedBytes uint64 = batchMemoryAfter.TotalAlloc - batchMemoryBefore.TotalAlloc
	var allocationCount uint64 = batchMemoryAfter.Mallocs - batchMemoryBefore.Mallocs
	t.Logf("aggregate=sampleGenerationPipeline calls=%d elapsed=%s ns_per_query=%.1f allocated_bytes=%d mallocs=%d", count, batchElapsed, meanNanoseconds, allocatedBytes, allocationCount)
	return samples, fmt.Sprintf("%x", digest.Sum(nil)[:8])
}

func referenceRecords(shard *catalog.Shard, ordinals []uint32, limit int) []catalog.Record {
	if len(ordinals) > limit {
		ordinals = ordinals[:limit]
	}
	result := make([]catalog.Record, 0, len(ordinals))
	for _, ordinal := range ordinals {
		record, _ := shard.Record(ordinal)
		result = append(result, record)
	}
	return result
}

func sameRecords(left, right []catalog.Record) bool {
	if len(left) != len(right) {
		return false
	}
	for index := range left {
		if left[index] != right[index] {
			return false
		}
	}
	return true
}

func sampleGenerationPath(t *testing.T, reader *generation.Reader, path string, count int) ([]time.Duration, string) {
	t.Helper()
	samples := make([]time.Duration, count)
	digest := sha256.New()
	var batchMemoryBefore runtime.MemStats = runtime.MemStats{}
	runtime.ReadMemStats(&batchMemoryBefore)
	var batchStarted time.Time = time.Now()
	for index := range samples {
		started := time.Now()
		record, exists, err := reader.Path(path)
		samples[index] = time.Since(started)
		if err != nil || !exists {
			t.Fatalf("generation path exists=%v err=%v", exists, err)
		}
		_, _ = digest.Write([]byte(record.ObjectID()))
	}
	var batchElapsed time.Duration = time.Since(batchStarted)
	var batchMemoryAfter runtime.MemStats = runtime.MemStats{}
	runtime.ReadMemStats(&batchMemoryAfter)
	var meanNanoseconds float64 = float64(batchElapsed.Nanoseconds()) / float64(count)
	var allocatedBytes uint64 = batchMemoryAfter.TotalAlloc - batchMemoryBefore.TotalAlloc
	var allocationCount uint64 = batchMemoryAfter.Mallocs - batchMemoryBefore.Mallocs
	t.Logf("aggregate=sampleGenerationPath calls=%d elapsed=%s ns_per_query=%.1f allocated_bytes=%d mallocs=%d", count, batchElapsed, meanNanoseconds, allocatedBytes, allocationCount)
	return samples, fmt.Sprintf("%x", digest.Sum(nil)[:8])
}

func sampleGenerationName(t *testing.T, reader *generation.Reader, name string, limit uint32, count int) ([]time.Duration, string) {
	t.Helper()
	samples := make([]time.Duration, count)
	digest := sha256.New()
	var batchMemoryBefore runtime.MemStats = runtime.MemStats{}
	runtime.ReadMemStats(&batchMemoryBefore)
	var batchStarted time.Time = time.Now()
	for index := range samples {
		started := time.Now()
		records, err := reader.Name(name, limit)
		samples[index] = time.Since(started)
		if err != nil || len(records) != int(limit) {
			t.Fatalf("generation name results=%d err=%v", len(records), err)
		}
		_, _ = digest.Write([]byte(records[0].ObjectID()))
	}
	var batchElapsed time.Duration = time.Since(batchStarted)
	var batchMemoryAfter runtime.MemStats = runtime.MemStats{}
	runtime.ReadMemStats(&batchMemoryAfter)
	var meanNanoseconds float64 = float64(batchElapsed.Nanoseconds()) / float64(count)
	var allocatedBytes uint64 = batchMemoryAfter.TotalAlloc - batchMemoryBefore.TotalAlloc
	var allocationCount uint64 = batchMemoryAfter.Mallocs - batchMemoryBefore.Mallocs
	t.Logf("aggregate=sampleGenerationName calls=%d elapsed=%s ns_per_query=%.1f allocated_bytes=%d mallocs=%d", count, batchElapsed, meanNanoseconds, allocatedBytes, allocationCount)
	return samples, fmt.Sprintf("%x", digest.Sum(nil)[:8])
}
