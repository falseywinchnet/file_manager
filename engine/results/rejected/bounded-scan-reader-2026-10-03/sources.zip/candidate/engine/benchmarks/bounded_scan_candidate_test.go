package benchmarks

// Private differential control, sharing only the existing formula oracle and
// fixture. Cursor/page shapes are test values, not a service contract.
import (
	"context"
	"crypto/sha256"
	"encoding/json"
	"hash"
	"path/filepath"
	"strings"
	"testing"

	"filemanager/engine/internal/catalog"
	"filemanager/engine/internal/generation"
)

func boundedSubstringPage(ctx context.Context, reader *generation.Reader, query substringQuery, next uint64) (substringPage, uint64, error) {
	var page substringPage = substringPage{Cursor: substringCursor{Generation: reader.Metadata().Generation, Query: query, Next: next}}
	var scan *generation.BoundedScanCandidate = nil
	var err error = nil
	scan, err = generation.NewBoundedScanCandidate(reader, ctx, 4<<20, 64<<10)
	if err != nil {
		return substringPage{}, 0, err
	}
	page.Records = make([]catalog.Record, 0, substringPageResults)
	var lower string = strings.ToLower(query.Text)
	var prefix string = query.Scope + "/"
	var hasScope bool = query.Scope != ""
	var length uint64 = reader.Len()
	for page.Cursor.Next < length && page.Examined < substringPageRows && len(page.Records) < substringPageResults {
		var row catalog.Row = catalog.Row{}
		var exists bool = false
		row, exists, err = scan.Row(uint32(page.Cursor.Next))
		if err != nil {
			return substringPage{}, scan.ReadBytes(), err
		}
		if !exists {
			return substringPage{}, scan.ReadBytes(), substringInvalid
		}
		var path string = filepath.ToSlash(row.RelativePath)
		var relative string = path
		var eligible bool = true
		if hasScope {
			eligible = strings.HasPrefix(path, prefix)
			if eligible {
				relative = path[len(prefix):]
			}
		}
		if !query.Descendants && strings.Contains(relative, "/") {
			eligible = false
		}
		var matched bool = false
		if eligible {
			var normalized string = strings.ToLower(path)
			matched = strings.Contains(normalized, lower)
		}
		if matched {
			var record catalog.Record = catalog.Record{}
			record, exists, err = scan.Record(uint32(page.Cursor.Next))
			if err != nil {
				return substringPage{}, scan.ReadBytes(), err
			}
			if !exists || record.Name != row.Name || record.Identity != row.Identity {
				return substringPage{}, scan.ReadBytes(), substringInvalid
			}
			page.Records = append(page.Records, record)
		}
		page.Cursor.Next++
		page.Examined++
	}
	err = ctx.Err()
	if err != nil {
		return substringPage{}, scan.ReadBytes(), err
	}
	page.Complete = page.Cursor.Next == length
	return page, scan.ReadBytes(), nil
}

func boundedSubstringRun(ctx context.Context, reader *generation.Reader, query substringQuery) (substringSummary, uint64, error) {
	var summary substringSummary = substringSummary{}
	var digest hash.Hash = sha256.New()
	var encoder *json.Encoder = json.NewEncoder(digest)
	var next uint64 = 0
	var logicalBytes uint64 = 0
	for {
		var page substringPage = substringPage{}
		var pageBytes uint64 = 0
		var err error = nil
		page, pageBytes, err = boundedSubstringPage(ctx, reader, query, next)
		logicalBytes += pageBytes
		if err != nil {
			return substringSummary{}, logicalBytes, err
		}
		if page.Examined == 0 && !page.Complete {
			return substringSummary{}, logicalBytes, substringInvalid
		}
		summary.Pages++
		summary.Examined += page.Examined
		if len(page.Records) == 0 {
			summary.EmptyPages++
		}
		var index int = 0
		for index = 0; index < len(page.Records); index++ {
			err = encoder.Encode(page.Records[index])
			if err != nil {
				return substringSummary{}, logicalBytes, err
			}
			summary.Matches++
		}
		next = page.Cursor.Next
		if page.Complete {
			break
		}
	}
	summary = substringFinish(digest, summary)
	return summary, logicalBytes, nil
}

func TestBoundedScanSubstringDifferential(t *testing.T) {
	var reader *generation.Reader = nil
	reader, _, _, _ = substringBuild(t, 7)
	defer reader.Close()
	var queries []substringQuery = []substringQuery{
		{Text: "ancestor", Descendants: true}, {Text: "ancestor/014", Descendants: true},
		{Text: "a", Descendants: true}, {Text: "ÉCLAIR", Descendants: true},
		{Text: "e\u0301", Descendants: true}, {Text: "missing", Descendants: true},
		{Text: "ancestor", Scope: "bucket-050-AnCeStOr", Descendants: false},
		{Text: "ancestor", Descendants: false}, {Text: "099-plain", Descendants: true},
		{Text: "plain", Scope: "notes..old", Descendants: true},
	}
	var index int = 0
	for index = 0; index < len(queries); index++ {
		var expected substringSummary = substringSummary{}
		var actual substringSummary = substringSummary{}
		var bytes uint64 = 0
		var err error = nil
		expected, err = substringOracle(reader.Root(), queries[index])
		if err != nil {
			t.Fatal(err)
		}
		actual, bytes, err = boundedSubstringRun(context.Background(), reader, queries[index])
		if err != nil || actual.Digest != expected.Digest || actual.Matches != expected.Matches || actual.Examined != uint64(substringFixtureCount) {
			t.Fatalf("query=%+v got=%+v want=%+v err=%v", queries[index], actual, expected, err)
		}
		if queries[index].Text == "missing" && actual.EmptyPages != actual.Pages {
			t.Fatal("no-match pages did not progress")
		}
		t.Logf("query=%q scope=%q descendants=%v matches=%d pages=%d examined=%d read_bytes=%d digest=%x", queries[index].Text, queries[index].Scope, queries[index].Descendants, actual.Matches, actual.Pages, actual.Examined, bytes, actual.Digest)
	}
}
