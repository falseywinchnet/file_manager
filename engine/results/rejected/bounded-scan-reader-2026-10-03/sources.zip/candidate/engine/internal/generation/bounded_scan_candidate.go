package generation

// Private bounded scan experiment; no service capability is enabled here.
import (
	"context"
	"crypto/sha256"
	"encoding/binary"
	"errors"
	"io"
	"os"
	"path/filepath"

	"filemanager/engine/internal/catalog"
)

var ErrScanReadBudget error = errors.New("bounded scan logical read budget exhausted")
var ErrScanStringBudget error = errors.New("bounded scan stored string budget exceeded")

// These pure field decoders are shared with the legacy reader. Validation and
// I/O remain with their callers; neither decoder retains its input array.
func decodeStoredBinding(encoded *[bindingRecordSize]byte) storedBinding {
	var result storedBinding = storedBinding{
		object: binary.LittleEndian.Uint32(encoded[0:4]), parent: binary.LittleEndian.Uint32(encoded[4:8]),
		nameOffset: binary.LittleEndian.Uint64(encoded[8:16]),
		nameLength: uint64(binary.LittleEndian.Uint32(encoded[16:20])),
	}
	return result
}

type storedPath struct {
	offset  uint64
	length  uint64
	ordinal uint32
}

func decodeStoredPath(encoded *[pathRecordSize]byte) storedPath {
	var result storedPath = storedPath{
		offset:  binary.LittleEndian.Uint64(encoded[0:8]),
		length:  uint64(binary.LittleEndian.Uint32(encoded[8:12])),
		ordinal: binary.LittleEndian.Uint32(encoded[12:16]),
	}
	return result
}

// BoundedScanCandidate borrows a checked immutable Reader. Its owner must keep
// that reader open and must not run Check or Close concurrently with a scan.
// One accessor belongs to one request and is not concurrently callable. Returned
// rows/records own their strings; scratch is reused only after making that copy.
// Logical bytes include cache hits and admitted reads that later fail. They do
// not bound physical prefetch, result storage, or elapsed time. A cache lock or
// native ReadAt is synchronous and cannot be interrupted by these context checks.
type BoundedScanCandidate struct {
	reader        *Reader
	ctx           context.Context
	maximumBytes  uint64
	maximumString uint64
	used          uint64
	err           error
	scratch       []byte
}

func NewBoundedScanCandidate(reader *Reader, ctx context.Context, maximumBytes, maximumString uint64) (*BoundedScanCandidate, error) {
	if reader == nil || reader.file == nil || ctx == nil || reader.metadata.SegmentDigest == ([sha256.Size]byte{}) {
		return nil, errors.New("bounded scan requires a live digest-checked reader and context")
	}
	var scan *BoundedScanCandidate = &BoundedScanCandidate{
		reader: reader, ctx: ctx, maximumBytes: maximumBytes, maximumString: maximumString,
		used: 0, err: nil, scratch: nil,
	}
	var err error = scan.checkOwner()
	if err != nil {
		return nil, err
	}
	return scan, nil
}

func (s *BoundedScanCandidate) ReadBytes() uint64 { return s.used }

func (s *BoundedScanCandidate) fail(err error) error {
	if s.err == nil {
		s.err = err
	}
	return s.err
}

func (s *BoundedScanCandidate) checkContext() error {
	if s.err != nil {
		return s.err
	}
	var err error = s.ctx.Err()
	if err != nil {
		s.fail(err)
	}
	return s.err
}

// Stat checks the borrowed file's lifetime even when every read would hit cache.
// It observes this segment file, never the stored source paths. Concurrent owner
// closure is excluded by the borrow contract, not synchronized by this check.
func (s *BoundedScanCandidate) checkOwner() error {
	var err error = s.checkContext()
	if err != nil {
		return err
	}
	var info os.FileInfo = nil
	info, err = s.reader.file.Stat()
	if err != nil {
		s.fail(err)
		return s.err
	}
	if info.Size() < 0 || uint64(info.Size()) != s.reader.cache.fileSize {
		s.fail(errors.New("bounded scan segment size changed"))
	}
	return s.err
}

func (s *BoundedScanCandidate) reserve(length uint64) error {
	var err error = s.checkContext()
	if err != nil {
		return err
	}
	if length > s.maximumBytes-s.used {
		s.fail(ErrScanReadBudget)
		return s.err
	}
	s.used += length
	return nil
}

// Bounds are checked with subtraction before adding component-relative offsets.
func (s *BoundedScanCandidate) extent(part descriptor, offset, length uint64) error {
	var size uint64 = s.reader.cache.fileSize
	if part.offset > size || part.length > size-part.offset || offset > part.length || length > part.length-offset {
		s.fail(io.ErrUnexpectedEOF)
	}
	return s.err
}

// The caller has validated the extent and precharged the complete request.
// Align chunks to cache blocks so each <=32KiB call touches at most one block.
func (s *BoundedScanCandidate) readCharged(output []byte, offset uint64) error {
	var err error = nil
	for len(output) != 0 {
		err = s.checkContext()
		if err != nil {
			return err
		}
		var count int = readBlockSize - int(offset%readBlockSize)
		if count > len(output) {
			count = len(output)
		}
		err = s.reader.cache.readAt(output[:count], offset)
		if err != nil {
			s.fail(err)
		}
		err = s.checkContext()
		if err != nil {
			return err
		}
		offset += uint64(count)
		output = output[count:]
	}
	return nil
}

func (s *BoundedScanCandidate) readFixed(output []byte, part descriptor, offset uint64) error {
	var length uint64 = uint64(len(output))
	var err error = s.extent(part, offset, length)
	if err != nil {
		return err
	}
	err = s.reserve(length)
	if err != nil {
		return err
	}
	var absolute uint64 = part.offset + offset
	err = s.readCharged(output, absolute)
	return err
}

func (s *BoundedScanCandidate) bindingAt(ordinal uint32) (storedBinding, error) {
	var part descriptor = s.reader.header.descriptors[componentBindings-1]
	var offset uint64 = uint64(ordinal) * bindingRecordSize
	var encoded [bindingRecordSize]byte = [bindingRecordSize]byte{}
	var err error = s.readFixed(encoded[:], part, offset)
	if err != nil {
		return storedBinding{}, err
	}
	var result storedBinding = decodeStoredBinding(&encoded)
	if hasNonzero(encoded[20:24]) || uint64(result.object) >= s.reader.header.objectCount || uint64(result.parent) >= s.reader.header.objectCount {
		s.fail(errors.New("invalid bounded scan binding"))
		return storedBinding{}, s.err
	}
	return result, nil
}

func (s *BoundedScanCandidate) objectAt(ordinal uint32) (catalog.Object, error) {
	var part descriptor = s.reader.header.descriptors[componentObjects-1]
	var offset uint64 = uint64(ordinal) * objectRecordSize
	var encoded [objectRecordSize]byte = [objectRecordSize]byte{}
	var err error = s.readFixed(encoded[:], part, offset)
	if err != nil {
		return catalog.Object{}, err
	}
	var object catalog.Object = catalog.Object{}
	object, err = decodeObject(encoded[:])
	if err != nil {
		s.fail(err)
		return catalog.Object{}, s.err
	}
	return object, nil
}

func (s *BoundedScanCandidate) readString(part descriptor, offset, length uint64) (string, error) {
	var err error = s.extent(part, offset, length)
	if err != nil {
		return "", err
	}
	if length > maximumStoredString || length > s.maximumString {
		s.fail(ErrScanStringBudget)
		return "", s.err
	}
	err = s.reserve(length)
	if err != nil {
		return "", err
	}
	// The format's 1MiB cap establishes safe int narrowing on supported hosts.
	if int(length) > cap(s.scratch) {
		s.scratch = make([]byte, int(length))
	}
	s.scratch = s.scratch[:int(length)]
	var absolute uint64 = part.offset + offset
	err = s.readCharged(s.scratch, absolute)
	if err != nil {
		return "", err
	}
	var result string = string(s.scratch)
	return result, nil
}

func (s *BoundedScanCandidate) pathAt(ordinal uint32) (string, error) {
	var part descriptor = s.reader.header.descriptors[componentPaths-1]
	var encoded [pathRecordSize]byte = [pathRecordSize]byte{}
	var offset uint64 = uint64(ordinal) * pathRecordSize
	var err error = s.readFixed(encoded[:], part, offset)
	if err != nil {
		return "", err
	}
	var path storedPath = decodeStoredPath(&encoded)
	var tableLength uint64 = s.reader.header.bindingCount * pathRecordSize
	if path.ordinal != ordinal || tableLength > part.length || path.offset > part.length-tableLength {
		s.fail(errors.New("invalid bounded scan path record"))
		return "", s.err
	}
	var stringOffset uint64 = tableLength + path.offset
	var value string = ""
	value, err = s.readString(part, stringOffset, path.length)
	return value, err
}

func (s *BoundedScanCandidate) Record(ordinal uint32) (catalog.Record, bool, error) {
	var err error = s.checkOwner()
	if err != nil {
		return catalog.Record{}, false, err
	}
	if uint64(ordinal) >= s.reader.header.bindingCount {
		return catalog.Record{}, false, nil
	}
	var binding storedBinding = storedBinding{}
	binding, err = s.bindingAt(ordinal)
	if err != nil {
		return catalog.Record{}, false, err
	}
	var object catalog.Object = catalog.Object{}
	object, err = s.objectAt(binding.object)
	if err != nil {
		return catalog.Record{}, false, err
	}
	var name string = ""
	name, err = s.readString(s.reader.header.descriptors[componentNames-1], binding.nameOffset, binding.nameLength)
	if err != nil {
		return catalog.Record{}, false, err
	}
	var path string = ""
	path, err = s.pathAt(ordinal)
	if err != nil {
		return catalog.Record{}, false, err
	}
	var result catalog.Record = catalog.Record{
		Root: s.reader.root.ID, Path: filepath.Join(s.reader.root.Path, filepath.FromSlash(path)), Name: name,
		Kind: object.Kind, Size: object.Size, Mode: object.Mode, ModifiedUnixNano: object.ModifiedUnixNano, Identity: object.Identity,
	}
	err = s.checkContext()
	if err != nil {
		return catalog.Record{}, false, err
	}
	return result, true, nil
}

func (s *BoundedScanCandidate) Row(ordinal uint32) (catalog.Row, bool, error) {
	var err error = s.checkOwner()
	if err != nil {
		return catalog.Row{}, false, err
	}
	if uint64(ordinal) >= s.reader.header.bindingCount {
		return catalog.Row{}, false, nil
	}
	var binding storedBinding = storedBinding{}
	binding, err = s.bindingAt(ordinal)
	if err != nil {
		return catalog.Row{}, false, err
	}
	var object catalog.Object = catalog.Object{}
	object, err = s.objectAt(binding.object)
	if err != nil {
		return catalog.Row{}, false, err
	}
	var parent catalog.Object = catalog.Object{}
	parent, err = s.objectAt(binding.parent)
	if err != nil {
		return catalog.Row{}, false, err
	}
	var name string = ""
	name, err = s.readString(s.reader.header.descriptors[componentNames-1], binding.nameOffset, binding.nameLength)
	if err != nil {
		return catalog.Row{}, false, err
	}
	var path string = ""
	path, err = s.pathAt(ordinal)
	if err != nil {
		return catalog.Row{}, false, err
	}
	var result catalog.Row = catalog.Row{
		RelativePath: filepath.FromSlash(path), Name: name, Kind: object.Kind, Size: object.Size, Mode: object.Mode,
		ModifiedUnixNano: object.ModifiedUnixNano, Identity: object.Identity, Parent: parent.Identity,
	}
	err = s.checkContext()
	if err != nil {
		return catalog.Row{}, false, err
	}
	return result, true, nil
}
