package generation

import (
	"context"
	"errors"
	"math"
	"path/filepath"
	"strings"
	"testing"

	"filemanager/engine/api"
	"filemanager/engine/internal/catalog"
	"filemanager/engine/internal/workload"
)

func boundedScanFixture(t *testing.T, corpus workload.Corpus) *Reader {
	t.Helper()
	var root api.RootSpec = api.RootSpec{ID: "bounded-fixture", Path: filepath.Join(t.TempDir(), "logical-source")}
	var shard *catalog.Shard = nil
	var err error = nil
	shard, err = corpus.ReferenceShard(root)
	if err != nil {
		t.Fatal(err)
	}
	var path string = filepath.Join(t.TempDir(), "fixture.seg")
	var metadata Metadata = Metadata{}
	metadata, err = Write(path, 7, shard)
	if err != nil {
		t.Fatal(err)
	}
	var reader *Reader = nil
	reader, err = Open(path, root)
	if err != nil {
		t.Fatal(err)
	}
	err = reader.Check(metadata.SegmentDigest)
	if err != nil {
		reader.Close()
		t.Fatal(err)
	}
	return reader
}

func boundedScanNew(t *testing.T, reader *Reader, ctx context.Context, bytes, stringBytes uint64) *BoundedScanCandidate {
	t.Helper()
	var scan *BoundedScanCandidate = nil
	var err error = nil
	scan, err = NewBoundedScanCandidate(reader, ctx, bytes, stringBytes)
	if err != nil {
		t.Fatal(err)
	}
	return scan
}

func TestBoundedScanCompleteRecordsAndAccounting(t *testing.T) {
	var reader *Reader = boundedScanFixture(t, workload.CorrectnessV1())
	defer reader.Close()
	var scan *BoundedScanCandidate = boundedScanNew(t, reader, context.Background(), math.MaxUint64, maximumStoredString)
	var used uint64 = 0
	var ordinal uint32 = 0
	for ordinal = 0; uint64(ordinal) < reader.Len(); ordinal++ {
		var wantRow catalog.Row = catalog.Row{}
		var wantRecord catalog.Record = catalog.Record{}
		var row catalog.Row = catalog.Row{}
		var record catalog.Record = catalog.Record{}
		var exists bool = false
		var err error = nil
		wantRow, exists, err = reader.Row(ordinal)
		if err != nil || !exists {
			t.Fatal("legacy row", err)
		}
		wantRecord, exists, err = reader.Record(ordinal)
		if err != nil || !exists {
			t.Fatal("legacy record", err)
		}
		row, exists, err = scan.Row(ordinal)
		if err != nil || !exists || row != wantRow {
			t.Fatal("complete row mismatch", ordinal, err)
		}
		record, exists, err = scan.Record(ordinal)
		if err != nil || !exists || record != wantRecord {
			t.Fatal("complete record mismatch", ordinal, err)
		}
		var storedPathBytes uint64 = uint64(len(filepath.ToSlash(wantRow.RelativePath)))
		var recordBytes uint64 = bindingRecordSize + objectRecordSize + pathRecordSize + uint64(len(wantRow.Name)) + storedPathBytes
		used += 2*recordBytes + objectRecordSize
		if scan.ReadBytes() != used {
			t.Fatal("logical count mismatch", scan.ReadBytes(), used)
		}
		// Scratch now holds the last path; previously returned name stays owned.
		if row != wantRow || record != wantRecord {
			t.Fatal("scratch escaped")
		}
	}
	var absent catalog.Record = catalog.Record{}
	var exists bool = true
	var err error = nil
	absent, exists, err = scan.Record(uint32(reader.Len()))
	if err != nil || exists || absent != (catalog.Record{}) || scan.ReadBytes() != used {
		t.Fatal("EOF changed state")
	}
	var absentRow catalog.Row = catalog.Row{}
	absentRow, exists, err = scan.Row(math.MaxUint32)
	if err != nil || exists || absentRow != (catalog.Row{}) || scan.ReadBytes() != used {
		t.Fatal("row EOF changed state")
	}
}

func TestBoundedScanExactBudgetsAndStickyFailure(t *testing.T) {
	var reader *Reader = boundedScanFixture(t, workload.CorrectnessV1())
	defer reader.Close()
	var want catalog.Row = catalog.Row{}
	var exists bool = false
	var err error = nil
	want, exists, err = reader.Row(0)
	if err != nil || !exists {
		t.Fatal(err)
	}
	var nameBytes uint64 = uint64(len(want.Name))
	var pathBytes uint64 = uint64(len(filepath.ToSlash(want.RelativePath)))
	var exact uint64 = bindingRecordSize + 2*objectRecordSize + pathRecordSize + nameBytes + pathBytes
	var scan *BoundedScanCandidate = boundedScanNew(t, reader, context.Background(), exact, maximumStoredString)
	var row catalog.Row = catalog.Row{}
	row, exists, err = scan.Row(0)
	if err != nil || !exists || row != want || scan.ReadBytes() != exact {
		t.Fatal("exact budget failed", err)
	}
	row, exists, err = scan.Row(0)
	if !errors.Is(err, ErrScanReadBudget) || exists || row != (catalog.Row{}) || scan.ReadBytes() != exact {
		t.Fatal("cache hit was not charged")
	}
	row, exists, err = scan.Row(math.MaxUint32)
	if !errors.Is(err, ErrScanReadBudget) || exists || row != (catalog.Row{}) {
		t.Fatal("EOF erased sticky error")
	}
	// Every insufficient budget must fail without publishing any part of a row.
	var limit uint64 = 0
	for limit = 0; limit < exact; limit++ {
		scan = boundedScanNew(t, reader, context.Background(), limit, maximumStoredString)
		row, exists, err = scan.Row(0)
		if !errors.Is(err, ErrScanReadBudget) || exists || row != (catalog.Row{}) || scan.ReadBytes() > limit {
			t.Fatal("short row budget", limit, err)
		}
		var before uint64 = scan.ReadBytes()
		var record catalog.Record = catalog.Record{}
		record, exists, err = scan.Record(0)
		if !errors.Is(err, ErrScanReadBudget) || exists || record != (catalog.Record{}) || scan.ReadBytes() != before {
			t.Fatal("sticky record failure")
		}
	}
	var exactRecord uint64 = exact - objectRecordSize
	scan = boundedScanNew(t, reader, context.Background(), exactRecord, maximumStoredString)
	var record catalog.Record = catalog.Record{}
	record, exists, err = scan.Record(0)
	if err != nil || !exists || record.Name != want.Name || scan.ReadBytes() != exactRecord {
		t.Fatal("exact record budget")
	}
	scan = boundedScanNew(t, reader, context.Background(), exact, nameBytes-1)
	row, exists, err = scan.Row(0)
	if !errors.Is(err, ErrScanStringBudget) || exists || row != (catalog.Row{}) || cap(scan.scratch) != 0 || scan.ReadBytes() != bindingRecordSize+2*objectRecordSize {
		t.Fatal("string refusal allocated or charged", err)
	}
	scan = boundedScanNew(t, reader, context.Background(), bindingRecordSize+2*objectRecordSize+nameBytes-1, maximumStoredString)
	row, exists, err = scan.Row(0)
	if !errors.Is(err, ErrScanReadBudget) || exists || row != (catalog.Row{}) || cap(scan.scratch) != 0 {
		t.Fatal("read refusal allocated string")
	}
}

func TestBoundedScanOwnerAndCancellation(t *testing.T) {
	var reader *Reader = boundedScanFixture(t, workload.CorrectnessV1())
	defer reader.Close()
	var unchecked *Reader = nil
	var err error = nil
	unchecked, err = Open(reader.file.Name(), reader.Root())
	if err != nil {
		t.Fatal(err)
	}
	defer unchecked.Close()
	var scan *BoundedScanCandidate = nil
	scan, err = NewBoundedScanCandidate(unchecked, context.Background(), 1000, 1000)
	if err == nil || scan != nil {
		t.Fatal("unchecked reader accepted")
	}
	var ctx context.Context = nil
	var cancel context.CancelFunc = nil
	ctx, cancel = context.WithCancel(context.Background())
	defer cancel()
	scan = boundedScanNew(t, reader, ctx, 10000, 1000)
	var independent *BoundedScanCandidate = boundedScanNew(t, reader, context.Background(), 10000, 1000)
	var saved catalog.Record = catalog.Record{}
	var exists bool = false
	saved, exists, err = scan.Record(0)
	if err != nil || !exists {
		t.Fatal(err)
	}
	var before uint64 = scan.ReadBytes()
	cancel()
	var record catalog.Record = catalog.Record{}
	record, exists, err = scan.Record(1)
	if !errors.Is(err, context.Canceled) || exists || record != (catalog.Record{}) || scan.ReadBytes() != before {
		t.Fatal("cancellation changed result/budget")
	}
	record, exists, err = independent.Record(0)
	if err != nil || !exists || record != saved {
		t.Fatal("query state leaked into reader")
	}
	err = reader.Close()
	if err != nil {
		t.Fatal(err)
	}
	record, exists, err = independent.Record(0)
	if err == nil || exists || record != (catalog.Record{}) {
		t.Fatal("closed owner served warm cache", err)
	}
	if saved.Name == "" || saved.Path == "" {
		t.Fatal("returned ownership lost")
	}
	scan, err = NewBoundedScanCandidate(reader, context.Background(), 1000, 1000)
	if err == nil || scan != nil {
		t.Fatal("closed reader accepted", err)
	}
}

// A named context wrapper schedules real context cancellation at a selected
// read checkpoint. It changes no file bytes and injects no I/O/cache failure.
type scanCancelCheckpoint struct {
	context.Context
	cancel context.CancelFunc
	calls  int
	at     int
}

func (c *scanCancelCheckpoint) Err() error {
	c.calls++
	if c.calls == c.at {
		c.cancel()
	}
	var err error = c.Context.Err()
	return err
}

func TestBoundedScanChunkCancellationAndLongOwnedStrings(t *testing.T) {
	var name string = strings.Repeat("x", 70000)
	var corpus workload.Corpus = workload.Corpus{Name: "bounded-long-v1", Entries: []workload.Entry{{Object: 1, RelativePath: name, Kind: api.ObjectRegular}}}
	var reader *Reader = boundedScanFixture(t, corpus)
	defer reader.Close()
	var normal *BoundedScanCandidate = boundedScanNew(t, reader, context.Background(), 1<<20, maximumStoredString)
	var record catalog.Record = catalog.Record{}
	var exists bool = false
	var err error = nil
	record, exists, err = normal.Record(0)
	if err != nil || !exists || record.Name != name {
		t.Fatal("long string", err)
	}
	var ctx context.Context = nil
	var cancel context.CancelFunc = nil
	ctx, cancel = context.WithCancel(context.Background())
	defer cancel()
	var checkpoints scanCancelCheckpoint = scanCancelCheckpoint{Context: ctx, cancel: cancel, calls: 0, at: math.MaxInt}
	var scan *BoundedScanCandidate = boundedScanNew(t, reader, &checkpoints, 1<<20, maximumStoredString)
	// Directly exercise the same string accessor to identify the second chunk's
	// before/after boundary without relying on row orchestration call counts.
	checkpoints.at = checkpoints.calls + 5
	var value string = ""
	value, err = scan.readString(reader.header.descriptors[componentNames-1], 0, uint64(len(name)))
	if !errors.Is(err, context.Canceled) || value != "" || scan.ReadBytes() != uint64(len(name)) {
		t.Fatal("chunk cancellation/precharge", err, scan.ReadBytes())
	}
	if record.Name != name {
		t.Fatal("returned string borrowed reusable storage")
	}
}
