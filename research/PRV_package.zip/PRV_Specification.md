# Preference Ranked Voting (PRV)

## Consolidated technical specification and adversarial evaluation

**Status:** Complete deterministic draft 1.0  
**Date:** 2026-08-04  
**Scope:** Preference Ranked Voting only. The Authentic, Private, and Exclusive protocol is outside this document.  
**Source basis:** The PRV portion of the Drive document formerly titled *PERV APE*, with the later rules resolved in discussion and encoded in the companion reference implementation.

---

## 1. Purpose

Preference Ranked Voting is a ranked-choice voting method that completes every truncated ballot into one strict permutation before elimination begins. Completion is inferred from the rankings of voters whose expressed patterns are closest to the incomplete ballot. PRV then uses a lowest-first elimination count. For large candidate fields, it runs a sequence of fixed-offset mini-elections in which lower-bracket winners promote upward.

PRV has two distinct functions:

1. **Preference completion:** infer the ordering of candidates a voter did not rank.
2. **Winner selection:** eliminate candidates from the completed ballot profile until a winner remains.

The inferred rankings are operative votes, not merely descriptive metadata. They can determine the winner.

PRV does not enumerate all possible permutations. It constructs exactly one completed active-set permutation for each valid ballot.

---

## 2. Normative language

The words **MUST**, **MUST NOT**, **SHOULD**, and **MAY** identify requirements, recommendations, and optional behavior.

A conforming implementation MUST return the same result for the same candidate set, ballot multiset, and parameter set. It MUST NOT use ballot input order, candidate labels, hidden randomness, or implementation-specific iteration order as a tie-break.

---

## 3. Terms and notation

Let:

- `C` be the finite registered candidate set.
- `m = |C|` be the candidate count.
- `V` be the multiset of valid ballots.
- `n = |V|` be the valid-ballot count.
- `A ⊆ C` be the active candidate set of a full election or bracket.
- `E_b` be voter `b`'s recovered explicit ranking.
- `P_b` be voter `b`'s current projected or expanded ranking in the active election.
- `rank_b(c)` be the one-based position of candidate `c` on ballot `b`, when ranked.

A **strict ballot** is an ordered list with no repeated candidate and no equal rank.

A **truncated ballot** ranks at least one but fewer than all candidates.

A **projection** of a ballot onto active set `A` deletes every candidate outside `A` and preserves the relative order of the remaining candidates.

A **complete active permutation** contains every candidate in `A` exactly once.

A **perfect tie** is equality after every specified rank-sensitive comparison has been exhausted.

A **failure** is an official PRV result with no winner and a machine-readable reason code. PRV itself does not prescribe a rerun, runoff, vacancy rule, or external dispute procedure.

---

## 4. Parameters

A PRV deployment MUST publish its parameters before ballots are accepted.

| Parameter | Symbol | Default | Meaning |
|---|---:|---:|---|
| Bracketing activation threshold | `H` | 30 | Bracketing is used when `m > H`. |
| Bracket interval | `K` | 10 | Maximum number of candidates in an active mini-election. |
| Bracket seed decay | `d` | 1/2 | Each lower rank contributes half the preceding rank's seed value. |
| Tie policy |  | failure | A perfect tie produces no winner. |

`K` MUST be at least 2. The default `K = 10` creates nine new seed positions per level plus one promoted winner.

All geometric seed scores MUST be evaluated with exact rational arithmetic. Floating-point rounding MUST NOT create or break a tie.

---

## 5. Candidate and ballot validity

### 5.1 Candidate list

Candidate identifiers MUST be unique and fixed before counting. A withdrawal or addition after seed computation invalidates the count and requires a fresh run from the original ballots.

“Unlimited candidates” means PRV imposes no conceptual maximum. Every concrete election still has a finite registered set.

### 5.2 Normal ballot interface

The normal interface MUST accept only strict rankings. A voter MAY rank any positive number of candidates. Omitted candidates are unranked, not explicitly rejected.

A voter MUST NOT assign two candidates the same rank through the normal interface.

### 5.3 Rejected ballots

A ballot is rejected as invalid if it:

- contains an unknown candidate;
- repeats a candidate;
- contains an empty rank group;
- contains no ranked candidate and is therefore a blank abstention;
- cannot be recovered under the malformed equal-rank procedure.

A rejected ballot contributes no weight and is excluded from `n`.

### 5.4 Minimum election size

The election MUST record more valid ballots than registered candidates:

```text
n > m
```

This condition is tested globally before bracketing. If it fails, PRV returns `TOO_FEW_VALID_BALLOTS`.

Every valid ballot has weight 1. PRV does not fractionally split a ballot.

---

## 6. Malformed equal-rank recovery

Equal ranking is prohibited input, but imported, handwritten, or legacy ballots may contain tied rank groups. Such a ballot is treated as malformed recoverable input rather than as a valid equal-ranking ballot.

Example:

```text
A > (B = C) > D
```

The tied group occupies two consecutive strict positions. `D` is demoted below both `B` and `C`. The ballot remains one vote.

### 6.1 Recovery rule

For each tied group, from highest to lowest:

1. Preserve every already resolved candidate above the group.
2. Reserve consecutive positions for all candidates in the tied group.
3. Resolve one candidate at a time from the tied group using the nearest-pattern inference rule in Section 10, restricted to the unresolved tied candidates.
4. Recalculate the working prefix after each recovered rank.
5. Place all originally lower strict ranks after the recovered tied group.
6. Repeat for later tied groups.

The first candidate selected from `(B = C)` occupies the earlier position. No ballot weight is divided.

If all ranked candidates are tied, the procedure begins from an empty prefix and recursively selects the most common strict continuation from other usable ballots. This operationalizes the historical “most common combination” rule.

### 6.2 Recovery scheduling

Strict ballots form the initial recovery donor pool. Malformed ballots are ordered by the number of candidates occupying tied groups, from fewest to most. Ballots at the same recovery level are resolved from the same unchanged donor snapshot and committed simultaneously. Recovered ballots may become donors only for later recovery levels.

A perfect recovery tie returns `MALFORMED_TIE_PERFECT`. A lack of usable donor evidence returns `MALFORMED_TIE_NO_EVIDENCE`.

This recovery route SHOULD be disabled where the ballot interface can reliably reject equal marks at entry, because deliberately invoking recovery creates an avoidable strategic channel.

---

## 7. Pre-expansion candidate popularity

Candidate popularity is used only to seed brackets. It does not directly select the winner.

For candidate `c`, let `N_r(c)` be the number of recovered submitted ballots ranking `c` at position `r`. Omission contributes zero. The seed score is:

\[
S(c)=N_1(c)+\frac{N_2(c)}{2}+\frac{N_3(c)}{4}+\frac{N_4(c)}{8}+\cdots
\]

Equivalently:

\[
S(c)=\sum_{r=1}^{m}\frac{N_r(c)}{2^{r-1}}
\]

The score is calculated once from recovered submitted rankings before ordinary permutation expansion. Inferred rankings MUST NOT affect bracket placement.

### 7.1 Seed ties

Candidates are first sorted by descending `S(c)`.

If two candidates have equal scores, compare their explicit rank-support vectors lexicographically:

```text
(N1(c), N2(c), N3(c), ...)
```

More first-place support wins. If equal, compare second-place support, then third-place support, and continue.

If all position totals are identical, PRV returns `PERFECT_SEED_TIE`. Candidate names or registration order MUST NOT break the tie.

---

## 8. Fixed-offset bracketing

Bracketing is used when `m > H`. A bracket is a fixed index interval in the pre-expansion popularity order. It is not a bucket whose size is rebalanced.

Let the popularity order be:

```text
q0, q1, q2, ..., q(m-1)
```

where `q0` is most popular. Let:

```text
w = K - 1
```

Define fixed segments:

\[
S_j = (q_{jw}, q_{jw+1}, \ldots, q_{\min((j+1)w-1,m-1)})
\]

Each segment contains at most `K - 1` newly introduced candidates.

### 8.1 Promotion procedure

Process segments from the lowest populated index upward toward `S_0`:

1. The lowest segment runs first.
2. Its winner represents the eliminated lower field.
3. At the next level, the active set is the next higher segment plus the promoted winner.
4. The promoted winner occupies the one-candidate overlap position.
5. Every losing candidate from the lower level is permanently eliminated and does not reappear.
6. Continue until `S_0` plus the final promoted winner produces the overall winner.

If the lowest segment contains one candidate, that candidate promotes automatically.

### 8.2 Example with 34 candidates and `K = 10`

The seed segments are:

```text
S0: ranks  0-8
S1: ranks  9-17
S2: ranks 18-26
S3: ranks 27-33
```

Counting proceeds:

```text
ranks 27-33                         -> winner W3
ranks 18-26 + W3                   -> winner W2
ranks  9-17 + W2                   -> winner W1
ranks  0-8  + W1                   -> overall winner
```

Nothing is redistributed to make the bottom segment contain ten candidates.

### 8.3 Bracket-local ballot projection

Every mini-election is rebuilt from the recovered original ballot:

1. Delete candidates outside the active bracket.
2. Preserve the relative order of active candidates.
3. Retain an empty projection as a participating ballot in that mini-election.
4. Expand that projection only through the active candidates.

Example:

```text
Original:       2 > 19 > 31 > 22 > 5
Active bracket: 18-26 plus promoted 31
Projection:     19 > 31 > 22
```

If a later bracket contains candidates `0-8` plus `31`, the same original ballot is freshly projected again. No inferred ranking from the previous bracket is carried upward.

Candidates below the active bracket have already lost. Candidates above it are deferred, not treated as globally eliminated.

---

## 9. Expansion overview

All ballots are collected before expansion begins. In each full election or mini-election, every projected ballot MUST become a complete permutation of the active set before elimination begins.

Expansion proceeds one inferred candidate at a time. After each inferred rank, the ballot's newly expanded pattern is used for the next recursion.

An inferred relation is never reopened. If `D` has been inferred after `A > B > C`, the next round orders only candidates still missing after `D`.

Expanded rankings may serve as donor evidence in later committed expansion rounds. Ballots committed in the same synchronous batch do not influence one another inside that batch.

---

## 10. Nearest-pattern donor population

Let the target ballot's current pattern be:

```text
P = p1 > p2 > ... > pk
```

For a donor ballot `R`, determine the largest `j` such that the prefix:

```text
p1 > p2 > ... > pj
```

appears in `R` as an ordered subsequence. The candidates need not be adjacent.

For that longest matched prefix, record the earliest position vector in `R`:

```text
(posR(p1), posR(p2), ..., posR(pj))
```

Donor closeness is compared in this order:

1. Preserve the longest target prefix.
2. Among equal prefix lengths, place the pattern earlier in the donor ballot.
3. Compare the position vector lexicographically, thereby preferring fewer and earlier interposed candidates.

A donor preserving the full pattern with gaps outranks a donor preserving only a shorter exact prefix.

### 10.1 Example

Target:

```text
A > B > C
```

From closest to farther:

```text
A > B > C > X       positions (1,2,3)
A > B > X > C       positions (1,2,4)
A > X > B > C       positions (1,3,4)
X > A > B > C       positions (2,3,4)
A > B > X           preserves only A>B
```

Earlier placement outranks later placement. Preserving `A>B>C` outranks the shorter `A>B` pattern even when the shorter pattern is contiguous.

### 10.2 Closest informative class only

For one expansion round, PRV uses only donors in the single closest equivalence class.

A donor is informative when it currently ranks at least one active candidate missing from the target. If the closest class has no such candidate, skip it and consider the next closest informative class.

More distant classes receive no fractional weight and are not pooled into the current round.

---

## 11. One-rank recursive inference

For target pattern `P` and donor `R`, form the donor residual by deleting every candidate already in `P` while preserving donor order.

Example:

```text
Target P: A > B > C
Donor R:  A > X > B > C > D
Residual: X > D
```

The donor proposes `X` as the next inferred candidate. `X` is placed after the established target pattern, so the target grows to:

```text
A > B > C > X
```

This is deliberate. The donor's relative placement of `X` among the already established candidates is not allowed to reopen the target order.

### 11.1 Modal next candidate

Within the nearest informative donor class:

1. Each donor proposes the first candidate in its residual.
2. Count proposals.
3. Infer the candidate with the largest proposal count.
4. Infer exactly one rank.
5. Commit the batch.
6. Recalculate donor closeness from the newly expanded pattern.

Example:

```text
4 donors: A>B>C>D>E
3 donors: A>B>D>E>C
3 donors: A>B>E>C>D
Target:   A>B
```

`C` is inferred next because it is the most common immediate proposal, 4 to 3 to 3. Pairwise dominance at later positions does not replace the modal-next rule.

### 11.2 Conflicting exact matches

```text
3 donors: A>B>C>D
2 donors: A>B>D>C
Target:   A>B
```

The target becomes `A>B>C`, then `A>B>C>D`. The two incomplete ballots in a batch receive the same result from the same snapshot.

### 11.3 Silent donors

If the closest group contains:

```text
6 ballots: A>B>C
4 ballots: A>B
```

while target `A>B` needs another candidate, the four silent ballots supply no proposal. `C` receives 6 of 6 informative votes, not 6 of 10.

### 11.4 Sole remaining candidate

If exactly one active candidate remains unranked, that candidate MUST occupy the last position without a donor comparison.

---

## 12. First-disagreement tie-break during expansion

If candidates tie as the modal next proposal, use only the same nearest donor class.

For each tied candidate `c`, calculate its residual positional vector:

```text
T(c) = (number at residual rank 1,
        number at residual rank 2,
        number at residual rank 3, ...)
```

Compare vectors lexicographically. The first position at which support differs resolves the tie.

Example:

```text
5 donors residual: C>D>E
5 donors residual: D>E>C
```

`C` and `D` tie at residual rank 1. Compare their residual rank-2 support, then rank 3, until a difference appears.

If the vectors remain identical at every residual rank, return `PERFECT_EXPANSION_TIE`.

Example:

```text
5 donors: A>B>C>D
5 donors: A>B>D>C
Target:   A>B
```

`C` and `D` have identical residual vectors `(5,5)`. The election fails rather than choosing randomly.

---

## 13. Expansion scheduling

The scheduling rule gives operational meaning to:

- start with the most complete ballots;
- among equally complete ballots, prioritize ballots containing the highest-ranked shared candidates;
- process equal-priority ballots from the same snapshot.

### 13.1 Current shared-support vector

For candidate `c`, define its current positional support among the other ballots:

```text
H(c) = (current rank-1 appearances,
        current rank-2 appearances,
        current rank-3 appearances, ...)
```

Compare `H(c)` lexicographically. Higher appearances at an earlier rank outweigh any number of appearances considered only at a later comparison position.

For current ballot pattern:

```text
P = p1 > p2 > ... > pk
```

its priority signature is:

```text
Q(P) = (H(p1), H(p2), ..., H(pk))
```

Compare the support of the target's first-ranked candidate before its second-ranked candidate, and so on.

### 13.2 Scheduler

Repeat until every ballot is complete:

1. Find the greatest current length among incomplete ballots.
2. Restrict attention to ballots at that length.
3. Find the greatest shared-support priority signature.
4. Put every ballot with that exact length and signature into one batch.
5. Infer one candidate independently for each batch member from the unchanged current snapshot.
6. If any member reaches a perfect tie, fail the active election.
7. Commit all successful inferences simultaneously.
8. Recalculate lengths, support signatures, donor closeness, and proposals.

This removes ballot-file order as an influence. A prior ballot in a data file cannot become a donor earlier merely because it was stored first.

---

## 14. Elimination count

Elimination begins only after every active ballot is complete.

### 14.1 Round count

For each round:

1. Count first-place votes among remaining candidates.
2. If one candidate has more than half of all valid ballot weight, elect that candidate.
3. Otherwise identify the candidate with the fewest first-place votes.
4. If tied, compare second-place totals among the tied candidates.
5. Continue to third place and later positions until one candidate has the lexicographically lowest positional vector.
6. Eliminate that candidate.
7. Delete the eliminated candidate from every ballot and collapse the remaining ranks upward.
8. Repeat.

For candidate `c`, the round vector is:

```text
R(c) = (first-place total, second-place total, third-place total, ...)
```

The candidate with the lexicographically smallest vector is eliminated.

If multiple candidates have identical full round vectors, return `PERFECT_ELIMINATION_TIE`.

### 14.2 Final pair

When two candidates remain, the candidate with more first-place votes wins immediately. Because all ballots are complete, this is a majority of the active pair unless the totals are equal.

An equal final count returns `PERFECT_FINAL_TIE`.

No ballot exhausts after completion.

---

## 15. Perfect Condorcet-cycle detection

PRV distinguishes an exact symmetric cycle from a non-perfect cycle.

At each elimination round, construct the pairwise majority graph over the remaining candidates. A **perfect cycle** is declared when all three conditions hold:

1. The majority graph is strongly connected, so every remaining candidate lies in the same cycle structure.
2. Every remaining candidate has the same positional support vector.
3. Every remaining candidate has the same sorted vector of pairwise victory and defeat margins.

The canonical example is:

```text
3: A>B>C
3: B>C>A
3: C>A>B
```

Every candidate has positional vector `(3,3,3)`, one pairwise victory by 3, and one pairwise defeat by 3. PRV returns `PERFECT_CONDORCET_CYCLE`.

An unequal cycle proceeds through ordinary elimination. Pairwise comparisons do not otherwise select the winner.

The perfect-cycle detector is conservative and diagnostic. A complete positional tie would already prevent a unique elimination; the cycle code identifies the Condorcet-symmetric cause.

---

## 16. Failure states

A conforming implementation MUST expose at least these failure codes:

| Code | Meaning |
|---|---|
| `DUPLICATE_CANDIDATE_ID` | Registered candidate identifiers are not unique. |
| `TOO_FEW_CANDIDATES` | Fewer than two candidates remain at initialization. |
| `TOO_FEW_VALID_BALLOTS` | Valid ballots do not exceed registered candidates. |
| `INVALID_BRACKET_INTERVAL` | `K < 2`. |
| `MALFORMED_TIE_NO_EVIDENCE` | A tied rank group cannot be recovered. |
| `MALFORMED_TIE_PERFECT` | Equal-rank recovery remains perfectly tied. |
| `PERFECT_SEED_TIE` | Candidates remain identical after seed score and rank-support comparison. |
| `NO_EXPANSION_EVIDENCE` | More than one candidate remains missing and no donor can propose one. |
| `PERFECT_EXPANSION_TIE` | The nearest donor class cannot distinguish tied proposals. |
| `PERFECT_CONDORCET_CYCLE` | The remaining profile is exactly cycle-symmetric. |
| `PERFECT_ELIMINATION_TIE` | More than one candidate has the same complete elimination vector. |
| `PERFECT_FINAL_TIE` | The final pair has equal first-place support. |

A lower-bracket failure is an election failure. PRV does not skip a failed bracket or promote multiple candidates.

---

## 17. Audit record

A conforming count SHOULD publish or preserve an independently reproducible audit record containing:

1. Candidate identifiers and parameter values.
2. Accepted, rejected, and recovered ballot counts.
3. Every malformed recovery decision and donor class.
4. Exact rational seed scores and positional tie vectors.
5. Popularity order and fixed bracket segments.
6. Each bracket's active candidate set.
7. Each original bracket projection.
8. Each expansion batch, target pattern, nearest-match length, match positions, donor count, proposal totals, tie vectors, and inferred candidate.
9. Every completed ballot or a verifiable commitment to it.
10. Every elimination round, positional vector, eliminated candidate, and majority test.
11. The winner or exact failure code.

The privacy mechanism governing ballot-level publication is outside PRV and belongs in a separate authentication and privacy protocol.

---

## 18. Reference pseudocode

### 18.1 Full election

```text
PRV(ballots, candidates, H=30, K=10):
    recovered, rejected = validate_and_recover(ballots)
    require count(recovered) > count(candidates)

    if count(candidates) <= H:
        return MINI_PRV(project(recovered, candidates), candidates)

    seeds = sort_by_geometric_explicit_support(recovered, candidates)
    segments = fixed_segments(seeds, width=K-1)
    promoted = NONE

    for segment from lowest to highest:
        active = segment
        if promoted exists:
            active = active + promoted

        if count(active) == 1:
            promoted = active[0]
        else:
            local_ballots = project_original_ballots(recovered, active)
            promoted = MINI_PRV(local_ballots, active)
            if MINI_PRV failed:
                return failure

    return promoted
```

### 18.2 Mini-election

```text
MINI_PRV(projected_ballots, active):
    expanded = EXPAND(projected_ballots, active)
    if EXPAND failed:
        return failure

    remaining = active
    loop:
        if perfect_symmetric_cycle(expanded, remaining):
            return PERFECT_CONDORCET_CYCLE

        first = first_place_counts(expanded, remaining)
        if any candidate has > 50%:
            return candidate

        if count(remaining) == 2:
            return larger first count or PERFECT_FINAL_TIE

        vectors = all_positional_count_vectors(expanded, remaining)
        loser = unique lexicographic minimum
        if loser is not unique:
            return PERFECT_ELIMINATION_TIE

        delete loser from every ballot
```

### 18.3 Expansion

```text
EXPAND(ballots, active):
    current = ballots

    while any ballot is incomplete:
        L = greatest incomplete length
        level = incomplete ballots of length L
        Q = greatest shared-support signature in level
        batch = ballots in level with signature Q
        snapshot = current

        for ballot in batch:
            next = INFER_ONE(ballot, snapshot, active)
            if next failed:
                return failure

        append one inferred candidate to every batch ballot simultaneously

    return current
```

### 18.4 One inference

```text
INFER_ONE(target P, snapshot, active):
    missing = active minus P
    if count(missing) == 1:
        return sole missing candidate

    for every other donor R:
        j = longest prefix of P preserved as a subsequence of R
        positions = earliest position vector for that prefix
        residual = R with candidates in P removed
        discard donor if residual is empty

    choose donors with maximum j
    among those, choose lexicographically earliest positions
    proposals = first residual candidate from each chosen donor

    if one proposal has the highest count:
        return it

    compare tied proposals by residual positional support
    if one is lexicographically highest:
        return it

    return PERFECT_EXPANSION_TIE
```

---

# Part II. Worked demonstrations

## 19. Exact-match expansion

Submitted ballots:

```text
2: A>B
3: A>B>C>D
2: A>B>D>C
```

The two incomplete ballots are processed in one synchronous batch. The nearest donors preserve the exact `A>B` prefix. Proposal totals are `C:3`, `D:2`, so both targets infer `C`. Each then places the sole missing `D` last.

Completed profile:

```text
5: A>B>C>D
2: A>B>D>C
```

`A` already has every first-place vote, so it wins immediately. The inferred `C>D` relation still remains part of the sentiment record.

## 20. Nearest-pattern fallback

Target:

```text
A>B>C
```

Donors:

```text
20: A>B>Y>C>D>E
 8: A>X>B>C>E>D
```

Both groups preserve the full target pattern and begin with `A`. The first group has the earlier position vector for `B`, so only those 20 ballots are used for this round. Removing `A,B,C` from their rankings yields residual `Y>D>E`. The target infers `Y`, becomes `A>B>C>Y`, and recalculates its nearest donor class.

## 21. First-disagreement failure

```text
5: A>B>C>D
5: A>B>D>C
Target: A>B
```

`C` and `D` each receive five immediate proposals. Their residual positional vectors are both `(5,5)`. No rank distinguishes them, so PRV returns `PERFECT_EXPANSION_TIE`.

## 22. Perfect cycle

```text
3: A>B>C
3: B>C>A
3: C>A>B
```

First-place totals, every later positional total, and pairwise margins are rotationally identical. PRV returns `PERFECT_CONDORCET_CYCLE`.

## 23. Bracket ladder

With 34 candidates seeded `C00` through `C33` and 40 identical complete ballots ranking them in that order, default bracketing produces:

```text
C27-C33                  -> C27
C18-C26 + C27            -> C18
C09-C17 + C18            -> C09
C00-C08 + C09            -> C00
```

The companion self-test reproduces this path.

---

# Part III. Formal properties and attacks

## 24. Properties established by the algorithm

### 24.1 Determinism

The synchronous batch rule, exact arithmetic, and failure-on-perfect-tie rule make PRV deterministic. Ballot input order is irrelevant.

### 24.2 Anonymity

Permuting voter identities or the storage order of ballots does not change any count. The reference tests found zero differences across 500 random truncated profiles, each shuffled ten times.

### 24.3 Candidate-label neutrality

Relabeling every candidate consistently relabels the result. Candidate names never break a tie. The reference tests found zero differences across 500 random relabelings.

### 24.4 Majority criterion

A candidate with more than half of submitted first-place rankings wins before any elimination. Expansion never changes an explicitly ranked first choice.

### 24.5 Explicit Pareto dominance

If every valid ballot explicitly ranks `X` above `Y`, completion preserves that relation. While `X` remains, a ballot cannot transfer to `Y` before `X`. `Y` therefore cannot be uniquely elected over `X` under ordinary elimination. This protects explicit unanimous pairwise preference, not unanimity inferred from omissions.

### 24.6 No ballot exhaustion

Every active ballot is completed before counting, so removal of candidates cannot exhaust a ballot.

### 24.7 Bounded active candidate dimension

With bracketing, an active mini-election contains at most `K` candidates. This bounds per-bracket candidate complexity even when the global field is large.

---

## 25. Claims the method does not satisfy

The historical draft said PRV overcame Arrow's theorem, Gibbard-Satterthwaite, the participation paradox, and the Condorcet paradox. Under standard definitions, those claims do not hold.

### 25.1 Independence of irrelevant alternatives fails

Profile:

```text
2: B>A>C
2: C>A>B
1: A>C>B
```

`A` is eliminated first and `C` wins. Remove losing candidate `B`; the projected pair is:

```text
3: A>C
2: C>A
```

Now `A` wins. The social choice between `A` and `C` changed because `B` was present. Natural elimination does not establish independence of irrelevant alternatives.

### 25.2 Condorcet consistency fails

In the same profile, `A` defeats both `B` and `C` pairwise by 3 to 2, so `A` is the Condorcet winner. PRV elects `C` after eliminating `A` on first-place support.

PRV detects exact symmetric cycles, but it is not a Condorcet method.

### 25.3 Strategy-proofness fails

In the same five-voter profile, one voter whose true preference is:

```text
B>A>C
```

can report:

```text
A>B>C
```

The winner changes from `C` to `A`, which that voter prefers. Strategic success does not require foreknowledge of every ballot in principle; it requires enough information to identify a profitable report.

This is consistent with the Gibbard-Satterthwaite result for deterministic, non-dictatorial, onto single-winner rules with at least three alternatives.[2][3]

### 25.4 Participation fails

Before participation:

```text
3: B>C>A
2: A>C>B
2: C>B>A
```

`C` wins.

Add one voter with sincere ranking:

```text
A>C>B
```

The result becomes `B`. The added voter prefers the prior winner `C` to the new winner `B`, so abstention would have produced a better outcome for that voter.

### 25.5 Monotonicity fails

Original profile:

```text
3: A>C>B
3: C>B>A
2: B>A>C
1: B>C>A
```

`C` wins.

Move `C` upward on the last ballot:

```text
B>C>A  ->  C>B>A
```

New profile:

```text
3: A>C>B
4: C>B>A
2: B>A>C
```

Now `A` wins. Raising the original winner caused it to lose.

### 25.6 Later-no-harm fails under completion

Other voters:

```text
2: A>C>B
2: B>A>C
2: C>B>A
```

A voter's true preference is `A>B>C`.

- Submit only `A`: nearest completion becomes `A>C>B`; `A` wins.
- Submit `A>B`: completion is `A>B>C`; `B` wins.

Adding a lower preference harmed the voter. The same profile gives a profitable truncation strategy.

---

## 26. Expansion-specific attacks

### 26.1 Donor poisoning and amplification

Base profile:

```text
100: A>B
  5: A>B>C>D
  4: A>B>D>C
120: C>D>A>B
120: D>C>A>B
```

The 100 truncated ballots infer `C` after `A>B`, and `C` wins.

Add one `A>B>D>C` ballot. The donor population becomes 5 to 5, producing `PERFECT_EXPANSION_TIE` and no winner.

Add two such ballots instead. The donor population becomes 5 to 6, all 100 truncated ballots infer `D`, and `D` wins.

Two new ballots changed 100 existing completions. This is a multiplicative influence channel. Authentication can prevent fake voters, but genuine coordinated voters can still exploit it.

### 26.2 Tie denial of service

Because perfect ties intentionally fail, an actor who can estimate a donor count may try to add or withhold a ballot to create equality. The preceding profile shows a one-ballot denial of service.

Failure is transparent and avoids arbitrary selection, but it is not strategically neutral.

### 26.3 Missingness is not random

PRV treats completers in the nearest group as evidence for truncators. That inference is valid only when voters who continue ranking are informative about voters who stop at the same pattern. If truncation correlates with intensity, protest, uncertainty, or deliberate concealment, the donor group can be systematically unrepresentative.

The algorithm extracts a group-imputed preference, not the unobserved personal preference of the individual voter.

### 26.4 Recursive feedback

Committed inferred ranks can become evidence in later rounds. Synchronous batching removes file-order dependence, but it does not remove feedback. An early modal inference can increase the support of the same pattern in later recursions.

An audit SHOULD distinguish explicit, malformed-recovered, and ordinarily inferred ranks, even though the current counting rule gives all completed positions equal operative force.

### 26.5 Small nearest groups

Closeness takes priority over sample size. One extremely close donor can outrank thousands of slightly farther donors. This follows the selected rule but creates variance and targeted influence around rare patterns.

A minimum-donor threshold would reduce this risk, but no such threshold is part of the present PRV rule.

### 26.6 Empty bracket projections

A voter who ranked no active candidate retains an empty bracket projection. Its completion is derived from the other ballots, effectively reproducing the nearest consensus. A large number of empty projections can amplify the active majority ordering.

Removing empty projections would instead create bracket-level ballot exhaustion and change the denominator. The current specification retains them because every original valid vote participates in every bracket.

### 26.7 Malformed equal-rank signaling

If equal-rank recovery is available to voters rather than limited to import repair, a voter can deliberately submit a tie to outsource the order of candidates to the donor population. Implementations SHOULD prevent this at the ballot interface and mark recovery events in the audit.

---

## 27. Elimination-specific attacks

### 27.1 Center squeeze

A broadly preferred compromise can have little first-place support and be eliminated before polarized candidates. The Condorcet counterexample is the smallest three-candidate form of this problem.

### 27.2 Spoiler and nomination effects

Adding or removing a candidate can change transfers, elimination order, expansion distances, and bracket activation. PRV therefore remains vulnerable to strategic nomination and withdrawal.

### 27.3 Strategic burial and compromise

A voter can rank a threatening candidate artificially low or elevate a compromise to alter elimination and bracket seed order. The method's complexity may increase the information needed for reliable manipulation, but computational difficulty is not strategy-proofness.

### 27.4 Failure engineering

The complete positional tie rule avoids arbitrary tiebreaks but allows exact symmetry to halt an election. Organized factions can sometimes aim for a tie rather than a win.

---

## 28. Bracketing-specific attacks

### 28.1 Threshold discontinuity

A candidate field of `H` uses one full election. A field of `H+1` uses a promotion ladder. The rule changes discontinuously at the threshold.

Scaled example with `H=5`, `K=3`:

```text
2: C>B>D>E>A>F
1: D>A>E>C>B>F
1: C>D>B>E>A>F
1: A>D>E>B>C>F
1: A>D>C>E>B>F
1: B>A>D>C>E>F
```

Without universally last candidate `F`, five candidates are counted without bracketing and `A` wins. Add `F`, ranked last by every voter. Bracketing activates and `D` wins.

The companion fixtures include a default-scale case with 30 candidates and 35 voters where the unbracketed winner is `K06`; adding a 31st candidate ranked last by every voter activates default bracketing and changes the winner to `K05`.

### 28.2 Seed manipulation

Because lower rankings contribute to seed score, a voter can change bracket placement without changing first choice.

Scaled `H=5`, `K=3` profile:

```text
C>B>A>D>F>E
C>D>B>E>F>A
F>E>A>D>C>B   <- strategic voter
F>E>A>D>B>C
B>D>F>E>A>C
F>C>E>A>D>B
B>F>E>C>A>D
```

Truthful seed order produces winner `B`, the strategic voter's last choice. That voter keeps `F` first but reports:

```text
F>D>C>E>A>B
```

The seed order and bracket path change, and `F` wins.

### 28.3 Bye and path advantage

Higher-seeded candidates enter later and face fewer elimination stages. Lower candidates must survive every level. This is intentional computational condensation, but it is not outcome-equivalent to one full PRV election.

### 28.4 Bracket path dependence

In 300 random complete-ranking profiles with 31 candidates and 41 voters, both the bracketed and unbracketed implementations returned a winner in 281 profiles. Their winners differed in 96 of those profiles, 34.16 percent. This measures the effect of the bracket path under one artificial distribution, not an election forecast.

### 28.5 Candidate flooding

Registering extra low-support candidates can:

- cross the bracketing threshold;
- change fixed segment boundaries;
- change which candidate receives a bye;
- create seed ties;
- change lower-bracket projections and winners.

The requirement `n > m` limits but does not eliminate this attack.

### 28.6 Geometric decay choice

The one-half decay is clear and computationally convenient, but it is a normative parameter. A second-place ranking is exactly worth half a first-place ranking for seeding, a third is worth one quarter, and so forth. Different decay values can change every bracket boundary.

---

## 29. Computational attacks and safeguards

### 29.1 Complexity

For `n` ballots and active bracket size `K`, a straightforward cached implementation has approximate expansion cost:

\[
O(n^2K^2)
\]

There are at most `nK` one-rank inference decisions, each of which may inspect `n` donors and `K` positions. Elimination costs approximately `O(nK^2)`.

With `L = ceil(m/(K-1))` bracket levels, the rough total is:

\[
O(Ln^2K^2)
\]

The reference implementation prioritizes clarity and auditability. Production software SHOULD cache positional totals, pattern indexes, residuals, and nearest-class membership.

### 29.2 Resource denial

An adversary may submit highly diverse truncation patterns to maximize nearest-pattern searches and audit-log volume. Implementations SHOULD publish resource limits, use canonical pattern indexes, and reject syntactically invalid ballots before inference.

### 29.3 Numeric precision

Seed scores MUST use integers or rational numbers. Binary floating point can misorder very low-ranked support and silently break exact ties.

### 29.4 Reproducibility

The count SHOULD be implemented by at least two independent codebases against a shared public test suite. The companion Python implementation is a reference, not a certified production counter.

---

# Part IV. Simulation results

## 30. Complete three-candidate profiles

Method:

```text
Random seed: 20260805
Profiles: 20,000
Voters: uniformly selected from 5,7,9,...,21
Ballots: independent uniform complete rankings
Reports tested: every complete one-voter misreport
Monotonicity test: every one-ballot upward move of the current winner
Participation test: every possible added complete ballot
```

Results:

| Measure | Count | Rate |
|---|---:|---:|
| Resolved profiles | 19,578 | 97.89% of all profiles |
| Perfect-tie failures | 422 | 2.11% |
| Profiles with a Condorcet winner | 18,158 |  |
| PRV missed that Condorcet winner | 328 | 1.81% of Condorcet-present profiles |
| At least one profitable one-voter misreport | 1,600 | 8.17% of resolved profiles |
| At least one tested monotonicity failure | 381 | 1.95% of resolved profiles |
| At least one tested participation failure | 382 | 1.95% of resolved profiles |

The finite rates depend on the artificial profile distribution. The explicit counterexamples establish possibility; the rates do not establish real-world frequency.

## 31. Four-candidate truncation profiles

Method:

```text
Random seed: 20260806
Profiles: 3,000
Voters: 21
True ballots: independent uniform complete rankings
Submitted length: uniformly selected from 1,2,3,4
```

Results:

| Outcome | Count | Rate |
|---|---:|---:|
| Resolved truncated profiles | 872 | 29.07% |
| Perfect expansion tie | 2,113 | 70.43% |
| Perfect elimination tie | 15 | 0.50% |
| Both full and truncated versions resolved | 854 |  |
| Different winners among both-resolved cases | 208 | 24.36% |

Uniform random truncation is deliberately hostile to coherent pattern inference. The result shows that failure-on-perfect-tie can be frequent when the preference profile has little structure.

## 32. Thirty-one-candidate bracketing profiles

Method:

```text
Random seed: 20260809
Profiles: 300
Voters: 41
Candidates: 31
Ballots: independent uniform complete rankings
Bracket parameters: H=30, K=10
Comparison: bracketed PRV versus one unbracketed PRV election
```

Results:

| Outcome | Count |
|---|---:|
| Unbracketed resolved | 294 |
| Bracketed resolved | 284 |
| Both resolved | 281 |
| Different winners | 96 |
| Bracketed perfect-tie failures | 16 |

Bracketing is a distinct social-choice rule, not merely a performance optimization.

## 33. Determinism checks

```text
500 random truncated four-candidate profiles
10 random ballot-order shuffles per profile
Outcome differences: 0

500 random candidate relabelings
Outcome differences after inverse relabeling: 0
```

These are regression tests, not proofs. The scheduling and failure rules are constructed to provide the corresponding invariances.

---

# Part V. Deployment assessment

## 34. What PRV accomplishes

PRV provides:

- deterministic completion of truncated rankings;
- no exhausted ballots after completion;
- a transparent similarity hierarchy;
- one-rank recursive inference rather than factorial enumeration;
- explicit failure instead of hidden random tie-breaking;
- a fixed-size candidate ladder for large fields;
- a detailed audit trail of every inferred preference;
- broad sentiment extraction beyond first choices.

## 35. What PRV does not accomplish

PRV does not provide:

- strategy-proofness;
- independence of irrelevant alternatives;
- guaranteed participation safety;
- monotonicity;
- Condorcet consistency;
- immunity to strategic nomination;
- proof that inferred preferences equal individual latent preferences;
- authentication, uniqueness, secrecy, coercion resistance, or ballot-chain security.

Those are separate claims and, in several cases, impossible to combine under the standard unrestricted deterministic model.[1][2][3][4]

## 36. Recommended implementation controls

These controls do not change the voting rule:

1. Publish all parameters and code before the election.
2. Use strict-rank ballot interfaces and reserve equal-rank recovery for imports.
3. Preserve original ballots separately from every inferred completion.
4. Mark every rank by provenance: explicit, malformed-recovered, or inferred.
5. Use exact rational seed arithmetic.
6. Run independent implementations and compare complete audit transcripts.
7. Publish every failure code and the smallest decisive tie vector.
8. Freeze the candidate list before seed calculation.
9. Run pre-election public simulations against the expected candidate and voter counts.
10. Specify the legal consequence of PRV failure outside the counting algorithm.

## 37. Reference artifacts

The companion files are:

- `prv_reference.py`: executable reference implementation and regression demonstrations.
- `prv_self_test_output.json`: expected self-test output.
- `prv_simulation_fixtures.json`: explicit counterexamples, Monte Carlo parameters and counts, and the default-threshold candidate-addition fixture.
- `prv_simulations.py`: reproducibility runner for the reported random experiments.

Run:

```bash
python prv_reference.py --self-test --pretty
PYTHONPATH=. python prv_simulations.py --quick
```

---

## References

[1] Kenneth J. Arrow, *Social Choice and Individual Values*, 2nd ed., Yale University Press, 1963.

[2] Allan Gibbard, “Manipulation of Voting Schemes: A General Result,” *Econometrica* 41(4), 1973, pp. 587-601. DOI: 10.2307/1914083.

[3] Mark A. Satterthwaite, “Strategy-proofness and Arrow's Conditions: Existence and Correspondence Theorems for Voting Procedures and Social Welfare Functions,” *Journal of Economic Theory* 10(2), 1975, pp. 187-217. DOI: 10.1016/0022-0531(75)90050-2.

[4] Hervé Moulin, “Condorcet's Principle Implies the No Show Paradox,” *Journal of Economic Theory* 45(1), 1988, pp. 53-64. DOI: 10.1016/0022-0531(88)90253-0.
