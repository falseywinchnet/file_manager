Preference Ranked Voting (PRV) package

Files:
- PRV_Specification.md: consolidated normative specification and adversarial evaluation
- prv_reference.py: executable reference implementation
- prv_self_test_output.json: expected regression demonstration output
- prv_simulation_fixtures.json: explicit profiles, random seeds, and reported result counts
- prv_simulations.py: reproducibility runner; use --quick for reduced samples
- prv_simulations_quick_output.json: output from the reduced run

Commands:
  python prv_reference.py --self-test --pretty
  PYTHONPATH=. python prv_simulations.py --quick
