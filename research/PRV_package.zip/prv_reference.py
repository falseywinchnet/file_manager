#!/usr/bin/env python3
"""Reference implementation for Preference Ranked Voting (PRV).

This module implements the consolidated PRV rules in PRV_Specification.md.
It favors auditability and exactness over performance. All ties that remain
perfect after the specified rank-by-rank comparisons return an explicit
failure instead of using random or label-based tie-breaking.

The normal ballot interface accepts strict rankings only. For imports that
contain tied rank groups, the optional malformed-ballot recovery routine
resolves each tie block from the nearest strict preference patterns.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import asdict, dataclass, field
from fractions import Fraction
from functools import cmp_to_key
from itertools import permutations
from typing import Any, Iterable, Optional, Sequence
import argparse
import json
import random

Candidate = str
Ballot = tuple[Candidate, ...]
RawRank = Candidate | Sequence[Candidate]
RawBallot = Sequence[RawRank]


@dataclass(frozen=True)
class Failure:
    code: str
    detail: Any = None


@dataclass
class ElectionResult:
    winner: Optional[Candidate]
    failure: Optional[Failure]
    trace: list[dict[str, Any]] = field(default_factory=list)
    expanded_ballots: Optional[list[Ballot]] = None

    def summary(self) -> dict[str, Any]:
        return {
            "winner": self.winner,
            "failure": asdict(self.failure) if self.failure else None,
        }


class PRVError(ValueError):
    pass


def _parse_raw_ballot(raw: RawBallot, candidates: set[Candidate]) -> tuple[list[tuple[Candidate, ...]], Optional[str]]:
    groups: list[tuple[Candidate, ...]] = []
    seen: set[Candidate] = set()
    for item in raw:
        if isinstance(item, str):
            group = (item,)
        else:
            group = tuple(item)
            if not group:
                return [], "empty rank group"
        if len(set(group)) != len(group):
            return [], "duplicate candidate inside rank group"
        for candidate in group:
            if candidate not in candidates:
                return [], f"unknown candidate {candidate!r}"
            if candidate in seen:
                return [], f"repeated candidate {candidate!r}"
            seen.add(candidate)
        groups.append(group)
    if not groups:
        return [], "blank ballot"
    return groups, None


def _subsequence_match_key(pattern: Ballot, donor: Ballot) -> tuple[int, tuple[int, ...]]:
    """Return longest matched prefix length and its earliest position vector."""
    positions: list[int] = []
    start = 0
    for candidate in pattern:
        try:
            idx = donor.index(candidate, start)
        except ValueError:
            break
        positions.append(idx)
        start = idx + 1
    return len(positions), tuple(positions)


def _restricted_inference(prefix: Ballot, donors: Sequence[Ballot], allowed: set[Candidate]) -> tuple[Optional[Candidate], Optional[Failure], dict[str, Any]]:
    """Resolve one candidate from a malformed equal-rank block."""
    if len(allowed) == 1:
        candidate = next(iter(allowed))
        return candidate, None, {"reason": "sole tied candidate remaining"}

    evidence: list[tuple[int, tuple[int, ...], int, Ballot]] = []
    for donor_index, donor in enumerate(donors):
        residual = tuple(candidate for candidate in donor if candidate in allowed)
        if not residual:
            continue
        matched, positions = _subsequence_match_key(prefix, donor)
        evidence.append((matched, positions, donor_index, residual))

    if not evidence:
        return None, Failure("MALFORMED_TIE_NO_EVIDENCE", {"prefix": prefix, "allowed": sorted(allowed)}), {}

    best_match = max(item[0] for item in evidence)
    evidence = [item for item in evidence if item[0] == best_match]
    best_positions = min(item[1] for item in evidence)
    group = [item for item in evidence if item[1] == best_positions]

    first_counts = Counter(item[3][0] for item in group)
    best_first = max(first_counts.values())
    tied = [candidate for candidate, count in first_counts.items() if count == best_first]
    audit: dict[str, Any] = {
        "match_prefix_length": best_match,
        "match_positions": best_positions,
        "proposal_counts": dict(first_counts),
    }
    if len(tied) == 1:
        return tied[0], None, audit

    max_residual = max(len(item[3]) for item in group)
    vectors = {
        candidate: tuple(
            sum(1 for item in group if len(item[3]) > rank and item[3][rank] == candidate)
            for rank in range(max_residual)
        )
        for candidate in tied
    }
    best_vector = max(vectors.values())
    winners = [candidate for candidate, vector in vectors.items() if vector == best_vector]
    audit["tie_vectors"] = vectors
    if len(winners) != 1:
        return None, Failure("MALFORMED_TIE_PERFECT", {"prefix": prefix, "candidates": winners, "vectors": vectors}), audit
    return winners[0], None, audit


def normalize_and_recover_ballots(raw_ballots: Sequence[RawBallot], candidates: Sequence[Candidate]) -> tuple[Optional[list[Ballot]], Optional[Failure], list[dict[str, Any]], list[tuple[int, str]]]:
    """Validate ballots and recover imported equal-rank groups.

    Invalid ballots with unknown or repeated candidates are rejected. A blank
    ballot is treated as an abstention and rejected. Equal-rank ballots are
    recovered in synchronous tiers ordered by the number of tied candidate
    positions. Strict ballots form the initial donor pool.
    """
    candidate_set = set(candidates)
    parsed: list[tuple[int, list[tuple[Candidate, ...]]]] = []
    rejected: list[tuple[int, str]] = []
    strict: dict[int, Ballot] = {}
    malformed: list[tuple[int, list[tuple[Candidate, ...]], int]] = []

    for index, raw in enumerate(raw_ballots):
        groups, error = _parse_raw_ballot(raw, candidate_set)
        if error:
            rejected.append((index, error))
            continue
        tied_slots = sum(len(group) for group in groups if len(group) > 1)
        if tied_slots == 0:
            strict[index] = tuple(group[0] for group in groups)
        else:
            malformed.append((index, groups, tied_slots))

    recovered_trace: list[dict[str, Any]] = []
    donor_pool = list(strict.values())
    recovered: dict[int, Ballot] = {}

    for level in sorted({item[2] for item in malformed}):
        batch = [item for item in malformed if item[2] == level]
        snapshot = list(donor_pool)
        decisions: list[tuple[int, Ballot, list[dict[str, Any]]]] = []
        for index, groups, _ in batch:
            prefix: list[Candidate] = []
            ballot_audit: list[dict[str, Any]] = []
            for group in groups:
                if len(group) == 1:
                    prefix.append(group[0])
                    continue
                unresolved = set(group)
                while unresolved:
                    candidate, failure, audit = _restricted_inference(tuple(prefix), snapshot, unresolved)
                    ballot_audit.append({"prefix": tuple(prefix), "unresolved": sorted(unresolved), "choice": candidate, "audit": audit})
                    if failure:
                        return None, failure, recovered_trace + [{"phase": "malformed_recovery", "ballot": index, "failure": asdict(failure), "audit": ballot_audit}], rejected
                    assert candidate is not None
                    prefix.append(candidate)
                    unresolved.remove(candidate)
            decisions.append((index, tuple(prefix), ballot_audit))
        for index, ballot, ballot_audit in decisions:
            recovered[index] = ballot
            donor_pool.append(ballot)
            recovered_trace.append({"phase": "malformed_recovery", "level": level, "ballot": index, "recovered": ballot, "audit": ballot_audit})

    normalized: list[Ballot] = []
    accepted_indices = sorted(set(strict) | set(recovered))
    for index in accepted_indices:
        normalized.append(strict.get(index, recovered.get(index)))
    return normalized, None, recovered_trace, rejected


def _candidate_positional_vector(candidate: Candidate, states: Sequence[Ballot], active_size: int, exclude: Optional[int] = None) -> tuple[int, ...]:
    return tuple(
        sum(1 for index, ballot in enumerate(states) if index != exclude and len(ballot) > rank and ballot[rank] == candidate)
        for rank in range(active_size)
    )


def _ballot_priority_signature(index: int, states: Sequence[Ballot], active: Sequence[Candidate]) -> tuple[int, ...]:
    signature: list[int] = []
    for candidate in states[index]:
        signature.extend(_candidate_positional_vector(candidate, states, len(active), exclude=index))
    return tuple(signature)


def _infer_one(target_index: int, states: Sequence[Ballot], active: Sequence[Candidate]) -> tuple[Optional[Candidate], Optional[Failure], dict[str, Any]]:
    pattern = states[target_index]
    missing = [candidate for candidate in active if candidate not in pattern]
    if not missing:
        return None, None, {}
    if len(missing) == 1:
        return missing[0], None, {"reason": "sole remaining candidate"}

    pattern_set = set(pattern)
    donors: list[tuple[int, tuple[int, ...], int, Ballot]] = []
    for donor_index, donor in enumerate(states):
        if donor_index == target_index:
            continue
        residual = tuple(candidate for candidate in donor if candidate not in pattern_set)
        if not residual:
            continue
        matched, positions = _subsequence_match_key(pattern, donor)
        donors.append((matched, positions, donor_index, residual))

    if not donors:
        return None, Failure("NO_EXPANSION_EVIDENCE", {"target": pattern, "missing": missing}), {}

    best_match = max(item[0] for item in donors)
    donors = [item for item in donors if item[0] == best_match]
    best_positions = min(item[1] for item in donors)
    group = [item for item in donors if item[1] == best_positions]

    proposals = Counter(item[3][0] for item in group)
    best_count = max(proposals.values())
    tied = [candidate for candidate, count in proposals.items() if count == best_count]
    audit: dict[str, Any] = {
        "target": pattern,
        "match_prefix_length": best_match,
        "match_positions": best_positions,
        "donor_indices": [item[2] for item in group],
        "proposal_counts": dict(proposals),
    }
    if len(tied) == 1:
        return tied[0], None, audit

    max_residual = max(len(item[3]) for item in group)
    vectors = {
        candidate: tuple(
            sum(1 for item in group if len(item[3]) > rank and item[3][rank] == candidate)
            for rank in range(max_residual)
        )
        for candidate in tied
    }
    best_vector = max(vectors.values())
    winners = [candidate for candidate, vector in vectors.items() if vector == best_vector]
    audit["tie_vectors"] = vectors
    if len(winners) != 1:
        return None, Failure("PERFECT_EXPANSION_TIE", {"target": pattern, "candidates": winners, "vectors": vectors}), audit
    return winners[0], None, audit


def expand_ballots(projected_ballots: Sequence[Ballot], active: Sequence[Candidate]) -> tuple[Optional[list[Ballot]], Optional[Failure], list[dict[str, Any]]]:
    """Expand every projected ballot to a complete active-set permutation."""
    active = tuple(active)
    states = [tuple(candidate for candidate in ballot if candidate in active) for ballot in projected_ballots]
    trace: list[dict[str, Any]] = []
    step = 0

    while True:
        incomplete = [index for index, ballot in enumerate(states) if len(ballot) < len(active)]
        if not incomplete:
            return states, None, trace

        maximum_length = max(len(states[index]) for index in incomplete)
        level = [index for index in incomplete if len(states[index]) == maximum_length]
        signatures = {index: _ballot_priority_signature(index, states, active) for index in level}
        highest_signature = max(signatures.values())
        batch = [index for index in level if signatures[index] == highest_signature]

        snapshot = list(states)
        decisions: list[tuple[int, Candidate, dict[str, Any]]] = []
        for index in batch:
            candidate, failure, audit = _infer_one(index, snapshot, active)
            if failure:
                trace.append({
                    "phase": "expansion",
                    "step": step,
                    "batch": batch,
                    "failure": asdict(failure),
                    "audit": audit,
                })
                return None, failure, trace
            assert candidate is not None
            decisions.append((index, candidate, audit))

        for index, candidate, _ in decisions:
            states[index] = states[index] + (candidate,)

        trace.append({
            "phase": "expansion",
            "step": step,
            "current_length": maximum_length,
            "priority_signature": highest_signature,
            "batch": batch,
            "decisions": [
                {"ballot": index, "candidate": candidate, "audit": audit}
                for index, candidate, audit in decisions
            ],
        })
        step += 1


def _perfect_cycle_detail(ballots: Sequence[Ballot], remaining: Sequence[Candidate]) -> Optional[dict[str, Any]]:
    """Conservative detector for an exact symmetric Condorcet cycle."""
    if len(remaining) < 3:
        return None
    projected = [tuple(candidate for candidate in ballot if candidate in remaining) for ballot in ballots]
    voter_count = len(projected)
    positional = {
        candidate: tuple(sum(1 for ballot in projected if ballot[rank] == candidate) for rank in range(len(remaining)))
        for candidate in remaining
    }
    if len(set(positional.values())) != 1:
        return None

    margins: dict[tuple[Candidate, Candidate], int] = {}
    wins: dict[Candidate, set[Candidate]] = defaultdict(set)
    for i, left in enumerate(remaining):
        for right in remaining[i + 1:]:
            left_votes = sum(1 for ballot in projected if ballot.index(left) < ballot.index(right))
            right_votes = voter_count - left_votes
            margin = left_votes - right_votes
            margins[(left, right)] = margin
            margins[(right, left)] = -margin
            if margin > 0:
                wins[left].add(right)
            elif margin < 0:
                wins[right].add(left)

    def reachable(start: Candidate) -> set[Candidate]:
        seen = {start}
        stack = [start]
        while stack:
            current = stack.pop()
            for nxt in wins[current]:
                if nxt not in seen:
                    seen.add(nxt)
                    stack.append(nxt)
        return seen

    if any(len(reachable(candidate)) != len(remaining) for candidate in remaining):
        return None

    margin_signatures = {
        candidate: tuple(sorted(margins[(candidate, other)] for other in remaining if other != candidate))
        for candidate in remaining
    }
    if len(set(margin_signatures.values())) != 1:
        return None
    return {"positional_vectors": positional, "margin_signatures": margin_signatures}


def eliminate(expanded_ballots: Sequence[Ballot], active: Sequence[Candidate]) -> tuple[Optional[Candidate], Optional[Failure], list[dict[str, Any]]]:
    remaining = list(active)
    voter_count = len(expanded_ballots)
    trace: list[dict[str, Any]] = []
    round_number = 0

    while True:
        projected = [tuple(candidate for candidate in ballot if candidate in remaining) for ballot in expanded_ballots]
        first_counts_raw = Counter(ballot[0] for ballot in projected)
        first_counts = {candidate: first_counts_raw.get(candidate, 0) for candidate in remaining}

        cycle = _perfect_cycle_detail(expanded_ballots, tuple(remaining))
        if cycle:
            failure = Failure("PERFECT_CONDORCET_CYCLE", cycle)
            trace.append({"phase": "elimination", "round": round_number, "remaining": tuple(remaining), "first": first_counts, "failure": asdict(failure)})
            return None, failure, trace

        for candidate, count in first_counts.items():
            if 2 * count > voter_count:
                trace.append({"phase": "elimination", "round": round_number, "remaining": tuple(remaining), "first": first_counts, "winner": candidate, "reason": "majority"})
                return candidate, None, trace

        if len(remaining) == 2:
            left, right = remaining
            if first_counts[left] == first_counts[right]:
                failure = Failure("PERFECT_FINAL_TIE", first_counts)
                trace.append({"phase": "elimination", "round": round_number, "remaining": tuple(remaining), "first": first_counts, "failure": asdict(failure)})
                return None, failure, trace
            winner = left if first_counts[left] > first_counts[right] else right
            trace.append({"phase": "elimination", "round": round_number, "remaining": tuple(remaining), "first": first_counts, "winner": winner, "reason": "final pair"})
            return winner, None, trace

        vectors = {
            candidate: tuple(
                sum(1 for ballot in projected if ballot[rank] == candidate)
                for rank in range(len(remaining))
            )
            for candidate in remaining
        }
        lowest_vector = min(vectors.values())
        lowest = [candidate for candidate, vector in vectors.items() if vector == lowest_vector]
        if len(lowest) != 1:
            failure = Failure("PERFECT_ELIMINATION_TIE", {"candidates": lowest, "vectors": vectors})
            trace.append({"phase": "elimination", "round": round_number, "remaining": tuple(remaining), "first": first_counts, "vectors": vectors, "failure": asdict(failure)})
            return None, failure, trace

        eliminated = lowest[0]
        trace.append({"phase": "elimination", "round": round_number, "remaining": tuple(remaining), "first": first_counts, "vectors": vectors, "eliminated": eliminated})
        remaining.remove(eliminated)
        round_number += 1


def run_mini_prv(projected_ballots: Sequence[Ballot], active: Sequence[Candidate]) -> ElectionResult:
    expanded, failure, expansion_trace = expand_ballots(projected_ballots, active)
    if failure:
        return ElectionResult(None, failure, expansion_trace, None)
    assert expanded is not None
    winner, failure, elimination_trace = eliminate(expanded, active)
    return ElectionResult(winner, failure, expansion_trace + elimination_trace, expanded)


def seed_candidates(ballots: Sequence[Ballot], candidates: Sequence[Candidate]) -> tuple[Optional[tuple[Candidate, ...]], Optional[Failure], dict[Candidate, Fraction], dict[Candidate, tuple[int, ...]]]:
    scores: dict[Candidate, Fraction] = {}
    vectors: dict[Candidate, tuple[int, ...]] = {}
    for candidate in candidates:
        counts = tuple(
            sum(1 for ballot in ballots if len(ballot) > rank and ballot[rank] == candidate)
            for rank in range(len(candidates))
        )
        vectors[candidate] = counts
        scores[candidate] = sum((Fraction(count, 2**rank) for rank, count in enumerate(counts)), Fraction(0, 1))

    exact_groups: dict[tuple[Fraction, tuple[int, ...]], list[Candidate]] = defaultdict(list)
    for candidate in candidates:
        exact_groups[(scores[candidate], vectors[candidate])].append(candidate)
    ties = [group for group in exact_groups.values() if len(group) > 1]
    if ties:
        return None, Failure("PERFECT_SEED_TIE", {
            "groups": ties,
            "scores": {candidate: str(scores[candidate]) for candidate in candidates},
            "vectors": vectors,
        }), scores, vectors

    order = tuple(sorted(candidates, key=lambda candidate: (scores[candidate], vectors[candidate]), reverse=True))
    return order, None, scores, vectors


def run_prv(
    raw_ballots: Sequence[RawBallot],
    candidates: Sequence[Candidate],
    *,
    bracket_threshold: int = 30,
    bracket_interval: int = 10,
    require_more_ballots_than_candidates: bool = True,
) -> ElectionResult:
    """Run a full PRV election, including optional bracketing."""
    candidates = tuple(candidates)
    if len(set(candidates)) != len(candidates):
        return ElectionResult(None, Failure("DUPLICATE_CANDIDATE_ID"), [])
    if len(candidates) < 2:
        return ElectionResult(None, Failure("TOO_FEW_CANDIDATES"), [])
    if bracket_interval < 2:
        return ElectionResult(None, Failure("INVALID_BRACKET_INTERVAL", bracket_interval), [])

    ballots, failure, recovery_trace, rejected = normalize_and_recover_ballots(raw_ballots, candidates)
    if failure:
        return ElectionResult(None, failure, recovery_trace)
    assert ballots is not None

    validation = {
        "phase": "validation",
        "valid_ballots": len(ballots),
        "rejected_ballots": rejected,
        "candidate_count": len(candidates),
    }
    trace: list[dict[str, Any]] = [validation] + recovery_trace

    if require_more_ballots_than_candidates and len(ballots) <= len(candidates):
        failure = Failure("TOO_FEW_VALID_BALLOTS", {"valid_ballots": len(ballots), "candidates": len(candidates)})
        trace.append({"phase": "validation", "failure": asdict(failure)})
        return ElectionResult(None, failure, trace)

    if len(candidates) <= bracket_threshold:
        result = run_mini_prv(ballots, candidates)
        result.trace = trace + [{"phase": "bracketing", "enabled": False}] + result.trace
        return result

    order, failure, scores, vectors = seed_candidates(ballots, candidates)
    if failure:
        trace.append({"phase": "seeding", "failure": asdict(failure)})
        return ElectionResult(None, failure, trace)
    assert order is not None

    width = bracket_interval - 1
    segments = [order[start:start + width] for start in range(0, len(order), width)]
    trace.append({
        "phase": "seeding",
        "order": order,
        "scores": {candidate: str(scores[candidate]) for candidate in candidates},
        "vectors": vectors,
        "bracket_threshold": bracket_threshold,
        "bracket_interval": bracket_interval,
        "segments": segments,
    })

    promoted: Optional[Candidate] = None
    for bracket_index in range(len(segments) - 1, -1, -1):
        active = list(segments[bracket_index])
        if promoted is not None:
            active.append(promoted)

        if len(active) == 1:
            promoted = active[0]
            trace.append({"phase": "bracket", "index": bracket_index, "active": tuple(active), "winner": promoted, "reason": "automatic promotion"})
            continue

        projected = [tuple(candidate for candidate in ballot if candidate in active) for ballot in ballots]
        result = run_mini_prv(projected, tuple(active))
        trace.append({
            "phase": "bracket",
            "index": bracket_index,
            "active": tuple(active),
            "winner": result.winner,
            "failure": asdict(result.failure) if result.failure else None,
            "trace": result.trace,
        })
        if result.failure:
            return ElectionResult(None, result.failure, trace)
        promoted = result.winner

    return ElectionResult(promoted, None, trace)


# ---------- Demonstrations and regression tests ----------


def _repeat(ballot: Ballot, count: int) -> list[Ballot]:
    return [ballot] * count


def demonstration_results() -> dict[str, Any]:
    demos: dict[str, Any] = {}

    exact = (
        _repeat(("A", "B"), 2)
        + _repeat(("A", "B", "C", "D"), 3)
        + _repeat(("A", "B", "D", "C"), 2)
    )
    expanded, failure, _ = expand_ballots(exact, ("A", "B", "C", "D"))
    demos["exact_conflict"] = {
        "failure": asdict(failure) if failure else None,
        "expanded_counts": {">".join(ballot): count for ballot, count in Counter(expanded or []).items()},
    }

    condorcet_profile = _repeat(("B", "A", "C"), 2) + _repeat(("C", "A", "B"), 2) + _repeat(("A", "C", "B"), 1)
    demos["condorcet_counterexample"] = run_prv(condorcet_profile, ("A", "B", "C")).summary()

    cycle = _repeat(("A", "B", "C"), 3) + _repeat(("B", "C", "A"), 3) + _repeat(("C", "A", "B"), 3)
    demos["perfect_cycle"] = run_prv(cycle, ("A", "B", "C")).summary()

    short_others = _repeat(("A", "C", "B"), 2) + _repeat(("B", "A", "C"), 2) + _repeat(("C", "B", "A"), 2)
    demos["later_no_harm"] = {
        "A_only": run_prv(short_others + [("A",)], ("A", "B", "C")).summary(),
        "A_then_B": run_prv(short_others + [("A", "B")], ("A", "B", "C")).summary(),
    }

    base_poison = (
        _repeat(("A", "B"), 100)
        + _repeat(("A", "B", "C", "D"), 5)
        + _repeat(("A", "B", "D", "C"), 4)
        + _repeat(("C", "D", "A", "B"), 120)
        + _repeat(("D", "C", "A", "B"), 120)
    )
    demos["expansion_poisoning"] = {
        "base": run_prv(base_poison, ("A", "B", "C", "D")).summary(),
        "plus_one_D_donor": run_prv(base_poison + [("A", "B", "D", "C")], ("A", "B", "C", "D")).summary(),
        "plus_two_D_donors": run_prv(base_poison + _repeat(("A", "B", "D", "C"), 2), ("A", "B", "C", "D")).summary(),
    }

    candidates34 = tuple(f"C{index:02d}" for index in range(34))
    bracket_demo = run_prv([candidates34] * 40, candidates34)
    demos["bracket_34"] = {
        "winner": bracket_demo.winner,
        "path": [
            {"index": event["index"], "active": event["active"], "winner": event["winner"]}
            for event in bracket_demo.trace
            if event.get("phase") == "bracket"
        ],
    }
    return demos


def self_test() -> dict[str, Any]:
    demos = demonstration_results()
    assert demos["exact_conflict"]["expanded_counts"]["A>B>C>D"] == 5
    assert demos["condorcet_counterexample"]["winner"] == "C"
    assert demos["perfect_cycle"]["failure"]["code"] == "PERFECT_CONDORCET_CYCLE"
    assert demos["later_no_harm"]["A_only"]["winner"] == "A"
    assert demos["later_no_harm"]["A_then_B"]["winner"] == "B"
    assert demos["expansion_poisoning"]["base"]["winner"] == "C"
    assert demos["expansion_poisoning"]["plus_one_D_donor"]["failure"]["code"] == "PERFECT_EXPANSION_TIE"
    assert demos["expansion_poisoning"]["plus_two_D_donors"]["winner"] == "D"
    assert demos["bracket_34"]["winner"] == "C00"
    return {"status": "ok", "demonstrations": demos}


def main() -> None:
    parser = argparse.ArgumentParser(description="Preference Ranked Voting reference implementation")
    parser.add_argument("--self-test", action="store_true", help="run regression demonstrations")
    parser.add_argument("--pretty", action="store_true", help="pretty-print JSON")
    args = parser.parse_args()
    output = self_test() if args.self_test else demonstration_results()
    print(json.dumps(output, indent=2 if args.pretty else None, default=str))


if __name__ == "__main__":
    main()
