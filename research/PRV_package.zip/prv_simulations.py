#!/usr/bin/env python3
"""Reproduce the PRV adversarial simulations reported in PRV_Specification.md."""

from __future__ import annotations

from collections import Counter
from itertools import permutations
import argparse
import json
import random

from prv_reference import run_prv


def fast_complete_winner(ballots, candidates):
    remaining = list(candidates)
    voter_count = len(ballots)
    while True:
        projected = [tuple(c for c in b if c in remaining) for b in ballots]
        first = Counter(b[0] for b in projected)
        counts = {c: first.get(c, 0) for c in remaining}
        for c, count in counts.items():
            if 2 * count > voter_count:
                return c
        if len(remaining) == 2:
            a, b = remaining
            if counts[a] == counts[b]:
                return None
            return a if counts[a] > counts[b] else b
        vectors = {
            c: tuple(sum(1 for b in projected if b[r] == c) for r in range(len(remaining)))
            for c in remaining
        }
        least = min(vectors.values())
        losers = [c for c, vector in vectors.items() if vector == least]
        if len(losers) != 1:
            return None
        remaining.remove(losers[0])


def condorcet_winner(ballots, candidates):
    positions = [{c: i for i, c in enumerate(ballot)} for ballot in ballots]
    voter_count = len(ballots)
    for candidate in candidates:
        if all(
            candidate == other
            or 2 * sum(1 for p in positions if p[candidate] < p[other]) > voter_count
            for other in candidates
        ):
            return candidate
    return None


def raise_candidate(ballot, candidate, new_position):
    result = list(ballot)
    old_position = result.index(candidate)
    result.pop(old_position)
    result.insert(new_position, candidate)
    return tuple(result)


def complete_three_candidate_profiles(profile_count=20_000, seed=20260805):
    rng = random.Random(seed)
    candidates = ("A", "B", "C")
    rankings = list(permutations(candidates))
    voter_options = list(range(5, 22, 2))
    stats = Counter()

    for _ in range(profile_count):
        ballots = [rng.choice(rankings) for _ in range(rng.choice(voter_options))]
        winner = fast_complete_winner(ballots, candidates)
        if winner is None:
            stats["failure"] += 1
            continue
        stats["resolved"] += 1

        cw = condorcet_winner(ballots, candidates)
        if cw:
            stats["condorcet_exists"] += 1
            if cw != winner:
                stats["condorcet_miss"] += 1

        manipulable = False
        for voter_index, true_ranking in enumerate(ballots):
            for report in rankings:
                if report == true_ranking:
                    continue
                modified = list(ballots)
                modified[voter_index] = report
                new_winner = fast_complete_winner(modified, candidates)
                if new_winner and true_ranking.index(new_winner) < true_ranking.index(winner):
                    manipulable = True
                    break
            if manipulable:
                break
        stats["manipulable"] += int(manipulable)

        monotonicity_failure = False
        for voter_index, ranking in enumerate(ballots):
            old_position = ranking.index(winner)
            for new_position in range(old_position):
                modified = list(ballots)
                modified[voter_index] = raise_candidate(ranking, winner, new_position)
                new_winner = fast_complete_winner(modified, candidates)
                if new_winner and new_winner != winner:
                    monotonicity_failure = True
                    break
            if monotonicity_failure:
                break
        stats["monotonicity_fail"] += int(monotonicity_failure)

        participation_failure = False
        for new_ballot in rankings:
            new_winner = fast_complete_winner(ballots + [new_ballot], candidates)
            if new_winner and new_winner != winner and new_ballot.index(winner) < new_ballot.index(new_winner):
                participation_failure = True
                break
        stats["participation_fail"] += int(participation_failure)

    return dict(stats)


def truncation_profiles(profile_count=3_000, seed=20260806):
    rng = random.Random(seed)
    candidates = ("A", "B", "C", "D")
    rankings = list(permutations(candidates))
    stats = Counter()

    for _ in range(profile_count):
        truthful = [rng.choice(rankings) for _ in range(21)]
        submitted = [ranking[:rng.randint(1, 4)] for ranking in truthful]
        full = run_prv(truthful, candidates)
        truncated = run_prv(submitted, candidates)
        key = truncated.failure.code if truncated.failure else "resolved"
        stats[f"trunc_{key}"] += 1
        if full.winner and truncated.winner:
            stats["both_resolved"] += 1
            if full.winner != truncated.winner:
                stats["winner_diff"] += 1
    return dict(stats)


def bracket_profiles(profile_count=300, seed=20260809):
    rng = random.Random(seed)
    candidates = tuple(f"X{i:02d}" for i in range(31))
    stats = Counter()

    for _ in range(profile_count):
        ballots = [tuple(rng.sample(candidates, len(candidates))) for _ in range(41)]
        unbracketed = run_prv(ballots, candidates, bracket_threshold=100, bracket_interval=10)
        bracketed = run_prv(ballots, candidates, bracket_threshold=30, bracket_interval=10)
        stats["un_failure" if unbracketed.failure else "un_resolved"] += 1
        stats["br_failure" if bracketed.failure else "br_resolved"] += 1
        if unbracketed.winner and bracketed.winner:
            stats["both_resolved"] += 1
            if unbracketed.winner != bracketed.winner:
                stats["divergent"] += 1
    return dict(stats)


def order_invariance(profile_count=500, shuffles=10, seed=20260810):
    rng = random.Random(seed)
    candidates = ("A", "B", "C", "D")
    differences = 0
    for _ in range(profile_count):
        ballots = []
        for _ in range(21):
            ranking = tuple(rng.sample(candidates, len(candidates)))
            ballots.append(ranking[:rng.randint(1, 4)])
        base = run_prv(ballots, candidates)
        signature = (base.winner, base.failure.code if base.failure else None)
        for _ in range(shuffles):
            shuffled = list(ballots)
            rng.shuffle(shuffled)
            result = run_prv(shuffled, candidates)
            if (result.winner, result.failure.code if result.failure else None) != signature:
                differences += 1
                break
    return {"profiles": profile_count, "shuffles_per_profile": shuffles, "outcome_differences": differences}


def run_all(full=True):
    scale = 1 if full else 0.05
    return {
        "three_candidate_complete_odd_electorates": complete_three_candidate_profiles(max(100, int(20_000 * scale))),
        "four_candidate_uniform_truncation": truncation_profiles(max(100, int(3_000 * scale))),
        "thirty_one_candidate_bracketing": bracket_profiles(max(20, int(300 * scale))),
        "order_invariance": order_invariance(max(20, int(500 * scale)), shuffles=10),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--quick", action="store_true", help="run reduced samples rather than the published full samples")
    parser.add_argument("--output", help="write JSON to a file")
    args = parser.parse_args()
    results = run_all(full=not args.quick)
    text = json.dumps(results, indent=2)
    if args.output:
        with open(args.output, "w", encoding="utf-8") as handle:
            handle.write(text + "\n")
    print(text)


if __name__ == "__main__":
    main()
